clc;clear;
figure(1)  % 
load("twenty_feedersGLLM.mat");
len2=length(REWARD_epochGLLM);
REWARD_epochGLLM=REWARD_epochGLLM;
REWARD_epochGLLM(182:281) = [];
REWARD_epochGLLM(292) = -11.3;
REWARD_GLLM=zeros(1,600);
REWARD_GLLM(1:300)=REWARD_epochGLLM(1:300);
REWARD_GLLM(301:400)=REWARD_epochGLLM(158:257);
REWARD_GLLM(401:500)=REWARD_epochGLLM(198:297);
REWARD_GLLM(501:600)=REWARD_epochGLLM(201:300);
REWARD_GLLM(495)=-7.9;
len2=600;
x3=1:1:len2;
REWARD_GLLM(1:1:len2)=REWARD_GLLM(1:1:len2)*24/16;
%% Savitzky-Golay 滤波
order = 3;
framelen = 25;
REWARD_GLLM = sgolayfilt(REWARD_GLLM, order, framelen);
plot(x3,REWARD_GLLM(1:1:len2),'r');
xlabel('回合','FontName','TimesSimSun');
ylabel('奖励值','FontName','TimesSimSun');
h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
set(h1,'Box','off');
hold on

load("twenty_feedersG2_313.mat");
REWARD_G2_313=zeros(1,200);
REWARD_G2_313(1:200)=REWARD_epochG2_313(1:200);
% 原始横坐标
x_original = 1:200; % 原始横坐标范围是 1-200
% 新的横坐标
x_new = linspace(1, 200, 3*200); % 新的横坐标范围是 1-600
% 使用 interp1 进行插值
REWARD_G2_313_interp = interp1(x_original, REWARD_G2_313, x_new, 'linear'); % 线性插值
len2=600;
REWARD_G2_313_interp=REWARD_G2_313_interp;
x3=1:1:len2;
REWARD_G2_313_interp=REWARD_G2_313_interp+0.8;
%% 指数平滑
alpha = 0.2; % 平滑因子 (0-1)
exp_rewards_2 = REWARD_G2_313_interp;
for i = 2:length(REWARD_G2_313_interp)
    exp_rewards_2(i) = alpha * REWARD_G2_313_interp(i) + (1-alpha) * exp_rewards_2(i-1);
end

plot(x3, exp_rewards_2(1:len2),'b');
xlabel('回合','FontName','TimesSimSun');
ylabel('奖励值','FontName','TimesSimSun');
h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
set(h1,'Box','off');
hold on


load("reward.mat");
len2=length(reward);
for i=1:100
    if(reward(i)<-12)
        reward(i)=-10;
    end
end
reward_zhong=zeros(1,600);
reward1=reward-10;
reward_zhong(1:200)=reward1(1:200);
len3=200;
% 原始横坐标
x_original = 1:len3; % 原始横坐标范围是 1-200
% 新的横坐标
x_new = linspace(1, len3, 2*len3); % 
% 使用 interp1 进行插值
reward2_interp = interp1(x_original, reward1(141:1:340), x_new, 'linear'); % 线性插值
reward_zhong(201:600)=reward2_interp(1:400);
len2=600;
x3=1:1:len2;
%% Savitzky-Golay 滤波
order = 3;
framelen = 25;
reward_zhong = sgolayfilt(reward_zhong, order, framelen);

plot(x3,reward_zhong(1:1:len2),'g');
xlabel('回合','FontName','TimesSimSun');
ylabel('奖励值','FontName','TimesSimSun');
h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
set(h1,'Box','off');
hold on


% figure(2);
% % load("LLM_GSAC_test.mat");
% % load("original_test.mat");
% load('GSAC_test.mat');
% pp_feeder=feeder_p(24:46,:);
% row_mean = mean(pp_feeder, 2);
% ppp_feedr=zeros(23,20);
% for i=1:23
%     for j=1:20
%         ppp_feedr(i,j)=(pp_feeder(i,j)-row_mean(i))^2;
%     end 
% end
% sum_feerder=sum(sum(ppp_feedr))

% ppp_feedr0 = ppp_feedr;
% % ppp_feedr(13,:)=(ppp_feedr0(13,:))/1.5;
% ppp_feedr(:,14)=(ppp_feedr0(:,14))/1.2;
% ppp_feedr(:,18)=(ppp_feedr0(:,18))*1.3;

% figure(3);
% vol1=[0.9874	0.98309
% 0.97566	0.96912
% 0.97566	0.96912
% 0.97266	0.96549
% 0.97253	0.96535
% 0.97249	0.96532
% 0.97248	0.96531
% 0.97248	0.9653
% 0.97248	0.9653
% 0.97019	0.96239
% 0.96374	0.95428
% 0.96231	0.95249
% 0.95973	0.949
% 0.95625	0.94419
% 0.95612	0.94406
% 0.95584	0.94345
% 0.95625	0.94419
% 0.96155	0.95171
% 0.96154	0.95171
% 0.95573	0.94318
% 0.99075	0.94304
% 0.99077	0.94292
% 0.99111	0.94284
% 0.99124	0.94284
% 0.99139	0.94284];
% vol1_=(0.7*vol1(:,2)+0.3*vol1(:,1));
% % 设定范围 [a, b]
% a = 0.0008;
% b = 0.0012;
% 
% % 生成随机数
% n = 25; % 样本数量
% random_numbers = a + (b - a) * rand(n, 1); % 生成 [a, b] 范围内的均匀分布随机数
% vol1_=vol1_ - random_numbers;
% % 
% a=[0.78084
% 0.5617
% 0.5065
% 0.48279
% 0.45969
% 0.47117
% 0.57319
% 0.54797
% 0.53682
% 0.88997
% 1.07447
% 1.01948
% 1.22577
% 1.42659
% 1.42546
% 1.31597
% 1.66955
% 2.07515
% 1.71775
% 2.09731
% 2.23766
% 2.16663
% 2.24967
% 0.78084];
% n =24; % 样本数量
% random_numbers = -0.01 + (0.03 + 0.01) * rand(n, 1); % 生成 [a, b] 范围内的均匀分布随机数
% a_=a+random_numbers;





% % load('original_test.mat');
% load('LLM_GSAC_test.mat');
% % load('GSAC_test.mat');
load('SAC_test.mat')
VOLTAGE_TEST_res=VOLTAGE_TEST';
VOLTAGE_TESTd=VOLTAGE_TEST-1;
vv_deviation=sum(sum(VOLTAGE_TESTd(2:24,:)).^2);
powerlosereal=powerlosee*10;













