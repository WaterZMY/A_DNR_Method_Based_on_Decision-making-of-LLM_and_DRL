% 假设已有奖励数据 (替换为您的实际数据)
rewards = -10 + rand(1,600)*5 - 10; % 模拟 [-10, -15] 范围内的数据

%% 移动平均平滑
windowSize = 20;
ma_rewards = movmean(rewards, windowSize);

%% 指数平滑
alpha = 0.2; % 平滑因子 (0-1)
exp_rewards = rewards;
for i = 2:length(rewards)
    exp_rewards(i) = alpha * rewards(i) + (1-alpha) * exp_rewards(i-1);
end

%% Savitzky-Golay 滤波
order = 3;
framelen = 25;
sg_rewards = sgolayfilt(rewards, order, framelen);

%% 绘制结果对比
figure('Position', [100, 100, 800, 400])
plot(rewards, 'Color', [0.7 0.7 0.7], 'LineWidth', 1); hold on;
plot(ma_rewards, 'b', 'LineWidth', 1.5);
plot(exp_rewards, 'r', 'LineWidth', 1.5);
plot(sg_rewards, 'g', 'LineWidth', 1.5);
hold off;

title('奖励曲线平滑方法比较');
xlabel('回合数'); 
ylabel('奖励值');
legend('原始数据', '移动平均', '指数平滑', 'SG滤波');
grid on;