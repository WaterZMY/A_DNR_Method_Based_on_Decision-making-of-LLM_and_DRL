import pandas as pd
import gurobipy as grb
import time
import numpy as np



def MISOCP(t, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv):
    ##################################### 参数的获得 ###########################################
    ##################################### HV参数 ###########################################
    m = grb.Model()

    pv_curve = curve.iloc[:, 2]
    load_curve = curve.iloc[:, 1]
    load_curve_time = load_curve[t]
    pv_curve_time =  pv_curve[t]
    feeder_list = [1,14,23,43,61,76,84,102,106,127,153,168,195,197,224,235,246,252,263,269]

    edge_list = []
    r = {}
    x = {}
    for i in range(len(edge_data)):  # 边的数量
        temp = edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        r_pu = temp.iloc[2]
        x_pu = temp.iloc[3]
        # I_max=temp.iloc[5]                    #支路最大电流
        edge_list.append((start_bus, end_bus))  # 把支路提取出来
        r[(start_bus, end_bus)] = r_pu  # 整理每条支路的电阻
        x[(start_bus, end_bus)] = x_pu  # 整理每条支路的电抗
        # Imax[(start_bus,end_bus)]=I_max          #整理每条支路的电流最大值
    edge_set1 = set(edge_list)
    edge_list = grb.tuplelist(edge_list)

    control_list = []
    for i in range(len(control_edge)):  # 边的数量
        temp = control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        control_list.append((start_bus, end_bus))  # 把支路提取出来

    control_set = set(control_list)
    fixed_list = list(edge_set1 - control_set)  #

    p_load0 = {}
    q_load0 = {}
    for i in range(len(bus_data)):
        temp_load = bus_data.iloc[i]  # 第i行
        bus = i
        p_load0[bus] = temp_load.iloc[1]/10000/1.8  # 从第0列开始  1.8
        q_load0[bus] = temp_load.iloc[2]/10000/1.8  # 从第0列开始  1.8

    pv_list = []
    pv = {}
    all_bus_list = list(range(1, 276-1))
    for i in range(len(pv_data)):
        temp = pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]/10
        pv[pv_bus_index] = pv_capacity
    no_pv_bus = list(set(all_bus_list) - set(pv_list))
    no_feeder_bus = grb.tuplelist(list(set(all_bus_list) - set(feeder_list)))

    p_load = {k: v * load_curve_time for k, v in p_load0.items()}
    q_load = {k: v * load_curve_time for k, v in q_load0.items()}


    edge_set = grb.tuplelist(current_edges)
    no_edge_list = grb.tuplelist(set(edge_list) - set(edge_set))

    X = m.addVars(edge_list, vtype=grb.GRB.BINARY, name='X')
    y = m.addVars(edge_list, name='y')
    m.addConstrs(X[i, j] == 1 for i, j in edge_set)
    m.addConstrs(X[i, j] == 0 for i, j in no_edge_list)

    v_list = [i + 1 for i in range(275)]  # 编号1-275
    v = m.addVars(v_list, name='v')  # 电压的平方，从1开始索引
    p = m.addVars(edge_list, lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p')  # 支路有功潮流 13条支路
    q = m.addVars(edge_list, lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q')  # 支路无功潮流
    l = m.addVars(edge_list, name='l')  # 电流的平方

    obj = m.addVar()
    p1 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p1')  # 上级主网购入有功
    q1 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q1')  # 上级主网购入无功
    p2 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p2')  # 上级主网购入有功
    q2 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q2')  # 上级主网购入无功
    p3 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p3')  # 上级主网购入有功
    q3 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q3')  # 上级主网购入无功
    p4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p4')  # 上级主网购入有功
    q4 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q4')  # 上级主网购入无功
    p5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p5')  # 上级主网购入有功
    q5 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q5')  # 上级主网购入无功
    p6 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p6')  # 上级主网购入有功
    q6 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q6')  # 上级主网购入无功
    p7 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p7')  # 上级主网购入有功
    q7 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q7')  # 上级主网购入无功
    p8 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p8')  # 上级主网购入有功
    q8 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q8')  # 上级主网购入无功
    p9 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p9')  # 上级主网购入有功
    q9 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q9')  # 上级主网购入无功
    p10 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p10')  # 上级主网购入有功
    q10 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q10')  # 上级主网购入无功
    p11 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p11')  # 上级主网购入有功
    q11 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q11')  # 上级主网购入无功
    p12 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p12')  # 上级主网购入有功
    q12 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q12')  # 上级主网购入无功
    p13 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p13')  # 上级主网购入有功
    q13 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q13')  # 上级主网购入无功
    p14 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p14')  # 上级主网购入有功
    q14 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q14')  # 上级主网购入无功
    p15 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p15')  # 上级主网购入有功
    q15 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q15')  # 上级主网购入无功
    p16 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p16')  # 上级主网购入有功
    q16 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q16')  # 上级主网购入无功
    p17 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p17')  # 上级主网购入有功
    q17 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q17')  # 上级主网购入无功
    p18 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p18')  # 上级主网购入有功
    q18 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q18')  # 上级主网购入无功
    p19 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p19')  # 上级主网购入有功
    q19 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q19')  # 上级主网购入无功
    p20 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='p20')  # 上级主网购入有功
    q20 = m.addVar(lb=-grb.GRB.INFINITY, ub=grb.GRB.INFINITY, name='q20')  # 上级主网购入无功

    m.update()

    opr = 0
    for i in v_list:
        opr += (v[i] - 1) ** 2
    for i, j in edge_list:
        opr += 0.45 * l[i, j] * r[i, j]
    m.addConstr(obj >= opr)

    m.addConstr(p1 == p.sum(1, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 1)) + p_load[1])  # 根节点
    m.addConstr(q1 == q.sum(1, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 1)) + q_load[1])  # 根节点
    m.addConstr(p2 == p.sum(14, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 14)) + p_load[14])  # 根节点
    m.addConstr(q2 == q.sum(14, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 14)) + q_load[14])  # 根节点
    m.addConstr(p3 == p.sum(23, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 23)) + p_load[23])  # 根节点
    m.addConstr(q3 == q.sum(23, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 23)) + q_load[23])  # 根节点
    m.addConstr(p4 == p.sum(43, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 43)) + p_load[43])  # 根节点
    m.addConstr(q4 == q.sum(43, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 43)) + q_load[43])  # 根节点

    m.addConstr(p5 == p.sum(61, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 61)) + p_load[61])  # 根节点
    m.addConstr(q5 == q.sum(61, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 61)) + q_load[61])  # 根节点
    m.addConstr(p6 == p.sum(76, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 76)) + p_load[76])  # 根节点
    m.addConstr(q6 == q.sum(76, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 76)) + q_load[76])  # 根节点
    m.addConstr(p7 == p.sum(84, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 84)) + p_load[84])  # 根节点
    m.addConstr(q7 == q.sum(84, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 84)) + q_load[84])  # 根节点
    m.addConstr(p8 == p.sum(102, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 102)) + p_load[102])  # 根节点
    m.addConstr(q8 == q.sum(102, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 102)) + q_load[102])  # 根节点

    m.addConstr(p9 == p.sum(106, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 106)) + p_load[106])  # 根节点
    m.addConstr(q9 == q.sum(106, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 106)) + q_load[106])  # 根节点
    m.addConstr(p10 == p.sum(127, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 127)) + p_load[127])  # 根节点
    m.addConstr(q10 == q.sum(127, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 127)) + q_load[127])  # 根节点
    m.addConstr(p11 == p.sum(153, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 153)) + p_load[153])  # 根节点
    m.addConstr(q11 == q.sum(153, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 153)) + q_load[153])  # 根节点
    m.addConstr(p12 == p.sum(168, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 168)) + p_load[168])  # 根节点
    m.addConstr(q12 == q.sum(168, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 168)) + q_load[168])  # 根节点

    m.addConstr(p13 == p.sum(195, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 195)) + p_load[195])  # 根节点
    m.addConstr(q13 == q.sum(195, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 195)) + q_load[195])  # 根节点
    m.addConstr(p14 == p.sum(197, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 197)) + p_load[197])  # 根节点
    m.addConstr(q14 == q.sum(197, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 197)) + q_load[197])  # 根节点
    m.addConstr(p15 == p.sum(224, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 224)) + p_load[224])  # 根节点
    m.addConstr(q15 == q.sum(224, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 224)) + q_load[224])  # 根节点
    m.addConstr(p16 == p.sum(235, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 235)) + p_load[235])  # 根节点
    m.addConstr(q16 == q.sum(235, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 235)) + q_load[235])  # 根节点

    m.addConstr(p17 == p.sum(246, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 246)) + p_load[246])  # 根节点
    m.addConstr(q17 == q.sum(246, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 246)) + q_load[246])  # 根节点
    m.addConstr(p18 == p.sum(252, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 252)) + p_load[252])  # 根节点
    m.addConstr(q18 == q.sum(252, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 252)) + q_load[252])  # 根节点
    m.addConstr(p19 == p.sum(263, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 263)) + p_load[263])  # 根节点
    m.addConstr(q19 == q.sum(263, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 263)) + q_load[263])  # 根节点
    m.addConstr(p20 == p.sum(269, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', 269)) + p_load[269])  # 根节点
    m.addConstr(q20 == q.sum(269, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', 269)) + q_load[269])  # 根节点

    pv_re = m.addVars(v_list, name='pv_re')  # 光伏无功出力
    pv_ac = m.addVars(v_list, name='pv_re')  # 光伏有功出力
    for k in range(1, 276):
        if (k in pv_list):
            m.addConstr(pv_ac[k] >= 0.95 * pv[k] * pv_curve_time)
            m.addConstr(pv_ac[k] <= pv[k] * pv_curve_time)
            m.addConstr(((pv_re[k]) ** 2 + (pv_ac[k]) ** 2) <= (1.1*pv[k]) ** 2)
        else:
            m.addConstr(pv_ac[k] == 0)
            m.addConstr(pv_re[k] == 0)

    m.addConstrs(p.sum(k, '*') - grb.quicksum(p[i, j] - r[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + p_load[k] -pv_ac[k] == 0 for k in no_feeder_bus)  #
    m.addConstrs(q.sum(k, '*') - grb.quicksum(q[i, j] - x[i, j] * l[i, j] for i, j in edge_list.select('*', k)) + q_load[k] -pv_re[k] == 0 for k in no_feeder_bus)  #
     # 大M法约束
    M = 1e4
    m.addConstrs(X[i, j] * M >= p[i, j] for i, j in edge_list)
    m.addConstrs(p[i, j] >= -X[i, j] * M for i, j in edge_list)
    m.addConstrs(X[i, j] * M >= q[i, j] for i, j in edge_list)
    m.addConstrs(q[i, j] >= -X[i, j] * M for i, j in edge_list)
    m.addConstrs(y[i, j] == (1 - X[i, j]) * M for i, j in edge_list)
    m.addConstrs(v[i] - v[j] <= y[i, j] + 2 * (r[i, j] * p[i, j] + x[i, j] * q[i, j]) - (r[i, j] ** 2 + x[i, j] ** 2) * l[i, j]for i, j in edge_list)
    m.addConstrs(v[i] - v[j] >= -y[i, j] + 2 * (r[i, j] * p[i, j] + x[i, j] * q[i, j]) - (r[i, j] ** 2 + x[i, j] ** 2) * l[i, j]for i, j in edge_list)
    m.addConstrs(l[i, j] * v[i] >= (p[i, j] ** 2 + q[i, j] ** 2) for i, j in edge_list)

    feeder_list = grb.tuplelist(feeder_list)
    m.addConstrs(v[i] == root_fixv ** 2 for i in feeder_list)
    m.addConstrs(v[i] >= 0.9*0.9 for i in v_list)
    m.addConstrs(v[i] <= 1.05*1.05 for i in v_list)

    m.setObjective(obj, grb.GRB.MINIMIZE)
    m.setParam('OutputFlag', 0)
    m.optimize()

    # print(m.status)  # 打印实际状态值
    # print(grb.GRB.INFEASIBLE)
    # 模型求解后，检查是否不可行
    # if m.status == grb.GRB.INFEASIBLE:
    #     # 计算最小不可行集
    #     m.computeIIS()
    #     # 将不可行的约束写入文件
    #     m.write("infeasible.ilp")
    #     # 输出不可行性报告
    #     print("The model is infeasible. The infeasible constraints are written to 'infeasible.ilp'.")

    voltage = np.zeros((1, 275))  # 节点1-275
    Pload = np.zeros((1, 275))
    Qload = np.zeros((1, 275))
    PPV = np.zeros((1, 275))
    branch = np.zeros((1, len(edge_list)))  # HV支路


    if m.status == grb.GRB.Status.OPTIMAL:

        branch_index = 0
        ############################ HV ################################
        # for i in [1,14,23,43,61,76,84,102,106,127,153,168,195,197,224,235,246,252,263,269]:
        #     voltage[0, i-1] = root_fixv**2

        for i in range(0,275):
            voltage[0, i] = v[i+1].x
            PPV[0,i] = pv_ac[i+1].x

        for key, value in p_load.items():
            Pload[0,key-1]=value

        for key, value in q_load.items():
            Qload[0,key-1]=value

        for i, j in edge_list:
            branch[0, branch_index] = X[i, j].x
            branch_index = branch_index + 1

        # print(np.sqrt(voltage_mv))
        return np.sqrt(voltage), Pload, Qload, PPV, branch,obj.x

    else:
        print("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
        Pload = np.zeros((1, 275))
        Qload = np.zeros((1, 275))
        PPV = np.zeros((1, 275))

        for key, value in p_load.items():
            Pload[0, key - 1] = value

        for key, value in q_load.items():
            Qload[0, key - 1] = value


        return np.zeros((1, 275)), Pload, Qload, np.zeros((1, 275)), np.zeros((1, len(edge_list))), 1

