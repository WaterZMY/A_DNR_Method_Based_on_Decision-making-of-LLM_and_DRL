# import numpy as np
# import torch
# import torch.nn as nn
# import yaml
# import re
# from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
# from pathlib import Path
# from accelerate import Accelerator
# from peft import LoraConfig, get_peft_model
# from torch.optim import AdamW
#
# #如果是model(),输出的是(batch_size, sequence_length, vocab_size)，也就是每个token预测下一个token的概率
# #如果是model.generate()，那就是生成回答
#
# #加载模型
# torch.manual_seed(1231)
# local_model_path = str(Path("~/chili/DeepSeek-R1-Distill-Qwen-7B").expanduser())   # 模型路径
# device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 检查是否有可用的GPU
# # 加载模型和分词器
# tokenizer = AutoTokenizer.from_pretrained(local_model_path, local_files_only=True, trust_remote_code=True)
# model = AutoModelForCausalLM.from_pretrained(
#     local_model_path,
#     local_files_only=True,
#     trust_remote_code=True,
#     torch_dtype=torch.bfloat16,
#     device_map="auto"
# )
#
# #系统prompt，需要自己设计
# system_prompt = """You are a helpful assistant. A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The Assistant first thinks about the reasoning process in the mind and then provides the user with the answer.\
# The reasoning process and answer are enclosed within <think> </think> and<answer> </answer> tags, respectively, i.e., <think> reasoning process here </think><answer> answer here </answer>."""
# #微调及训练参数config
# optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)
# num_pre_Q = 4
# clip_param = 0.2
# generation_config = GenerationConfig(
#             max_new_tokens=512,
#             do_sample=True, temperature = 0.9,
#             num_return_sequences = num_pre_Q,
#             pad_token_id=tokenizer.pad_token_id,
#         )
#
# lora_config = LoraConfig(
#     r=8,  # rank for low-rank adaptation (通常为8或16)
#     lora_alpha=16,  # LoRA超参数，通常为16
#     lora_dropout=0.1,  # LoRA的dropout率，通常为0.1
#     task_type='CAUSAL_LM',  # 任务类型
# )
# # 应用 LoRA 到模型
# model = get_peft_model(model, lora_config)
#
# def gen_answers(prompts):
#     tip_text = []
#     for x in prompts:
#         tip_text.append(tokenizer.apply_chat_template([
#             {"role": "system", "content": system_prompt},
#             {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True))
#     tip_inputs = tokenizer(tip_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)
#     prompt_length = tip_inputs["input_ids"].shape[-1]     #问题的长度
#     tip_inputs = {k: v.to(model.device) for k, v in tip_inputs.items()}
#     with torch.inference_mode():
#         tip_completion_ids = model.generate(**tip_inputs, generation_config=generation_config)
#     completion_ids = tip_completion_ids[:, prompt_length:]
#     answers = [tokenizer.decode(x).replace('<｜end▁of▁sentence｜>', '') for x in completion_ids]
#     return answers
#
# def gen_samples(prompts):
#     answers = gen_answers(prompts)    #根据prompt获得答案，比如得到了4个answers
#     # if len(answers) == 0: return None, None, None, None
#     rewards = []
#     for a in answers:
#         rewards.append(reward_function(a))
#     prompts_text = [tokenizer.apply_chat_template([
#              {"role": "system", "content": system_prompt},
#              {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True) for x in prompts]
#     prompt_inputs = tokenizer(prompts_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)["input_ids"]
#     output_ids = tokenizer(answers, return_tensors="pt", padding=True, padding_side="right", add_special_tokens=False)["input_ids"]
#     return prompt_inputs, output_ids, torch.tensor(rewards, dtype=torch.float32), answers #输出prompt对应的ID，答案对应的ID，还有answer
#
# #————————————————————————————————————！！！奖励函数定义,实际控制效果————————————————————————————————#
# def reward_function(answer):
#     # pattern = r'\d+\.\d+|\d+/\d+|\d+'
#     # nums = re.findall(pattern, answer) # 使用正则表达式在answer中查找所有数字
#     # if len(nums) == 0: return -1.0
#     # lastnum = nums[-1] # 用answer中最后一个数字和ground_truth做比较
#     # ans = parse(lastnum, extraction_config=[ExprExtractionConfig()])
#     # ground_truth = parse(item["A"], extraction_config=[ExprExtractionConfig()])
#     # return 1 if verify(ans, ground_truth) else -1
#     '''提取馈线编号并传递给RL智能体—————RL智能体与底层环境交互获取奖励'''
# # def reward_format(item, answer):
# #     # pattern = r"^<think>(?:(?!</?think>)[\s\S]*?)</think>\s*<answer>(?:(?!</?answer>)[\s\S]*?)</answer><\|im_end\|>$"
# #     pattern = r"^<think>.*?</think><answer>.*?</answer>$"
# #     return 1.25 if re.match(pattern, answer, re.DOTALL | re.VERBOSE) else -1
#     return 5
#
# def get_per_token_logps(logits, input_ids):
#     per_token_logps = []  # Use a loop to reduce memory peak.
#     for logits_row, input_ids_row in zip(logits, input_ids):
#         log_probs = logits_row.log_softmax(dim=-1)
#         token_log_prob = torch.gather(log_probs, dim=1, index=input_ids_row.unsqueeze(1)).squeeze(1)
#         per_token_logps.append(token_log_prob)
#     return torch.stack(per_token_logps)
#
# def gen_standard_sample(prompts): #生成每种prompt样本的结果，然后把不同的prompts存放到一个batch里面，batch是一个字典
#     prompt_inputs, output_ids, rewards, answers = gen_samples(prompts)
#     # if (rewards.max() - rewards.min()).item() < 0.01:
#     #     continue  # 如果奖励的方差很小，跳过
#     # 标准化奖励
#     rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-4)
#     # 计算每个问题重复次数，确保输入与输出数量一致
#     rep = output_ids.shape[0] // prompt_inputs.shape[0]
#     prompt_length = prompt_inputs.shape[1]
#     Qrep = prompt_inputs.repeat(1, rep).view(-1, prompt_length)
#     # 合并输入和输出
#     merged_ids = torch.cat([Qrep, output_ids], dim=1)  #输入Q和输出A拼接
#     # 计算其log
#     with torch.inference_mode():
#         mids = merged_ids.to(model.device)   #输入Q+输出A=input,数据转移到GPU
#         gen_logps = get_per_token_logps(model(mids).logits[:, :-1, :], mids[:, 1:])
#         record_logps = gen_logps[:, prompt_length - 1:].cpu()     #获取样本的概率分布
#     return prompt_length, rewards, merged_ids, record_logps       #返回奖励，合并的ID，以及每个合并ID的log分布
#
# def GRPO_step(batch,step):
#     loss = 0
#     for t in range(step):
#         prompt_length = torch.tensor(batch['plen'][t]).to(model.device)
#         inputs = batch['inputs'][t].to(model.device)
#         advantages = (batch['rewards'][t].unsqueeze(1)).to(model.device)  # normalized in generation
#         logits = model(inputs).logits
#         logits = logits[:, :-1, :]  # (B, L-1, V), exclude the last logit: it corresponds to the next token pred
#         input_ids = inputs[:, 1:]  # (B, L-1), exclude the first input ID since we don't have logits for it
#         per_token_logps = get_per_token_logps(logits, input_ids)
#         per_token_logps = per_token_logps[:, prompt_length - 1:]
#         # ref_per_token_logps = batch['refs'].to(per_token_logps.device)  #没有参考值，因此删去
#         # per_token_kl = torch.exp(ref_per_token_logps - per_token_logps) - (ref_per_token_logps - per_token_logps) - 1
#         completion_mask = (inputs[:, prompt_length:] != tokenizer.pad_token_id).int()
#
#         ratio = torch.exp(per_token_logps - batch['gen_logps'][t].to(model.device))
#         clipped_ratio = torch.clamp(ratio, 1 - clip_param, 1 + clip_param)
#         per_token_loss = -torch.min(ratio * advantages, clipped_ratio * advantages)   #loss function
#         # per_token_loss = -per_token_loss
#         loss += ((per_token_loss * completion_mask).sum(dim=1) / completion_mask.sum(dim=1)).mean()
#
#     return loss
#
# accelerator = Accelerator()
# episode = 1000
# step = 1
# my_prompt = ["馈线1：馈线2：请问该控制哪几条馈线上的开关"]      #以列表的形式存放，需要自己设计
# for ep in range(episode):
#     model.train()
#     batch = {
#         "plen": [],
#         "rewards": [],
#         "inputs": [], #Q和A的ID拼接
#         "gen_logps": [],
#     }
#     for t in range(step):
#         step_prompt = [my_prompt[t]]  #必须以列表的形式输入
#         # print(step_prompt)
#         model, step_prompt = accelerator.prepare(model, step_prompt)
#         prompt_length, rewards, merged_ids, record_logps = gen_standard_sample(step_prompt)
#         batch["plen"].append(prompt_length)
#         batch["rewards"].append(rewards)
#         batch["inputs"].append(merged_ids)
#         batch["gen_logps"].append(record_logps)
#
#     batch_loss = GRPO_step(batch,step)
#     accelerator.backward(batch_loss)
#     # 执行优化器的步进
#     optimizer.step()
#     # 梯度清零
#     optimizer.zero_grad()
#     # loss = GRPO_step(batch)
#
# # expanded_prompt = []
# # expanded_prompt.extend([my_prompt] * group_size)
# # decoded_outputs = get_answers(expanded_prompt)



import numpy as np
import torch
import torch.nn as nn
import yaml
import re
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from pathlib import Path
from accelerate import Accelerator
from peft import LoraConfig, get_peft_model
from torch.optim import AdamW

#如果是model(),输出的是(batch_size, sequence_length, vocab_size)，也就是每个token预测下一个token的概率
#如果是model.generate()，那就是生成回答

#加载模型
torch.manual_seed(1231)
local_model_path = str(Path("~/chili/DeepSeek-R1-Distill-Qwen-7B").expanduser())   # 模型路径
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 检查是否有可用的GPU
# 加载模型和分词器
tokenizer = AutoTokenizer.from_pretrained(local_model_path, local_files_only=True, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    local_model_path,
    local_files_only=True,
    trust_remote_code=True,
    torch_dtype=torch.bfloat16,
    device_map="auto"
)

#系统prompt，需要自己设计   下面的system_prompt要改
system_prompt = """You are an expert in the operation and coordination of distribution networks. In a system, there are multiple feeders, and users will provide you with data such as feeder numbers, node numbers, branches, and the voltage and power of each node. The safe voltage range is between 9.5kv and 1.05kv. Based on the data provided by the user, please analyze which feeders' switches should be controlled.\
                 The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, i.e., <answer> answer here </answer> tag must and should only be in the format similar to ‘Feeders 1, 2, 4’. <think> reasoning process here </think><answer> answer here </answer>."""
#微调及训练参数config
optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)
num_pre_Q = 4
clip_param = 0.2
generation_config = GenerationConfig(
            max_new_tokens=512,  # 变大
            do_sample=True, temperature = 0.9,
            num_return_sequences = num_pre_Q,
            pad_token_id=tokenizer.pad_token_id,
        )

lora_config = LoraConfig(
    r=8,  # rank for low-rank adaptation (通常为8或16)
    lora_alpha=16,  # LoRA超参数，通常为16
    lora_dropout=0.1,  # LoRA的dropout率，通常为0.1
    task_type='CAUSAL_LM',  # 任务类型
)
# 应用 LoRA 到模型
model = get_peft_model(model, lora_config)

def gen_answers(prompts):
    tip_text = []
    for x in prompts:
        tip_text.append(tokenizer.apply_chat_template([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True))
    tip_inputs = tokenizer(tip_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)
    prompt_length = tip_inputs["input_ids"].shape[-1]     #问题的长度
    tip_inputs = {k: v.to(model.device) for k, v in tip_inputs.items()}
    with torch.inference_mode():
        tip_completion_ids = model.generate(**tip_inputs, generation_config=generation_config)
    completion_ids = tip_completion_ids[:, prompt_length:]
    answers = [tokenizer.decode(x).replace('<｜end▁of▁sentence｜>', '') for x in completion_ids]
    return answers

def gen_samples(prompts):
    answers = gen_answers(prompts)    #根据prompt获得答案，比如得到了4个answers
    # if len(answers) == 0: return None, None, None, None
    rewards = []
    for a in answers:
        rewards.append(reward_function(a))
    prompts_text = [tokenizer.apply_chat_template([
             {"role": "system", "content": system_prompt},
             {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True) for x in prompts]
    prompt_inputs = tokenizer(prompts_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)["input_ids"]
    output_ids = tokenizer(answers, return_tensors="pt", padding=True, padding_side="right", add_special_tokens=False)["input_ids"]
    return prompt_inputs, output_ids, torch.tensor(rewards, dtype=torch.float32), answers #输出prompt对应的ID，答案对应的ID，还有answer

#————————————————————————————————————！！！奖励函数定义,实际控制效果————————————————————————————————#
def reward_function(answer):
#     pattern = r'\d+\.\d+|\d+/\d+|\d+'
#     nums = re.findall(pattern, answer) # 使用正则表达式在answer中查找所有数字
#     if len(nums) == 0: return -1.0
#     lastnum = nums[-1] # 用answer中最后一个数字和ground_truth做比较
#     ans = parse(lastnum, extraction_config=[ExprExtractionConfig()])
#     ground_truth = parse(item["A"], extraction_config=[ExprExtractionConfig()])
#     return 1 if verify(ans, ground_truth) else -1
#     '''提取馈线编号并传递给RL智能体—————RL智能体与底层环境交互获取奖励'''
# def reward_format(item, answer):
#     # pattern = r"^<think>(?:(?!</?think>)[\s\S]*?)</think>\s*<answer>(?:(?!</?answer>)[\s\S]*?)</answer><\|im_end\|>$"
#     pattern = r"^<think>.*?</think><answer>.*?</answer>$"
#     return 1.25 if re.match(pattern, answer, re.DOTALL | re.VERBOSE) else -1
    return 5

def get_per_token_logps(logits, input_ids):
    per_token_logps = []  # Use a loop to reduce memory peak.
    for logits_row, input_ids_row in zip(logits, input_ids):
        log_probs = logits_row.log_softmax(dim=-1)
        token_log_prob = torch.gather(log_probs, dim=1, index=input_ids_row.unsqueeze(1)).squeeze(1)
        per_token_logps.append(token_log_prob)
    return torch.stack(per_token_logps)

def gen_standard_sample(prompts): #生成每种prompt样本的结果，然后把不同的prompts存放到一个batch里面，batch是一个字典
    prompt_inputs, output_ids, rewards, answers = gen_samples(prompts)
    # if (rewards.max() - rewards.min()).item() < 0.01:
    #     continue  # 如果奖励的方差很小，跳过
    # 标准化奖励
    rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-4)
    # 计算每个问题重复次数，确保输入与输出数量一致
    rep = output_ids.shape[0] // prompt_inputs.shape[0]
    prompt_length = prompt_inputs.shape[1]
    Qrep = prompt_inputs.repeat(1, rep).view(-1, prompt_length)
    # 合并输入和输出
    merged_ids = torch.cat([Qrep, output_ids], dim=1)  #输入Q和输出A拼接
    # 计算其log
    with torch.inference_mode():
        mids = merged_ids.to(model.device)   #输入Q+输出A=input,数据转移到GPU
        gen_logps = get_per_token_logps(model(mids).logits[:, :-1, :], mids[:, 1:])
        record_logps = gen_logps[:, prompt_length - 1:].cpu()     #获取样本的概率分布
    return prompt_length, rewards, merged_ids, record_logps,answers       #返回奖励，合并的ID，以及每个合并ID的log分布

def GRPO_step(batch,step):
    loss = 0
    for t in range(step):
        prompt_length = torch.tensor(batch['plen'][t]).to(model.device)
        inputs = batch['inputs'][t].to(model.device)
        advantages = (batch['rewards'][t].unsqueeze(1)).to(model.device)  # normalized in generation
        logits = model(inputs).logits
        logits = logits[:, :-1, :]  # (B, L-1, V), exclude the last logit: it corresponds to the next token pred
        input_ids = inputs[:, 1:]  # (B, L-1), exclude the first input ID since we don't have logits for it
        per_token_logps = get_per_token_logps(logits, input_ids)
        per_token_logps = per_token_logps[:, prompt_length - 1:]
        # ref_per_token_logps = batch['refs'].to(per_token_logps.device)  #没有参考值，因此删去
        # per_token_kl = torch.exp(ref_per_token_logps - per_token_logps) - (ref_per_token_logps - per_token_logps) - 1
        completion_mask = (inputs[:, prompt_length:] != tokenizer.pad_token_id).int()

        ratio = torch.exp(per_token_logps - batch['gen_logps'][t].to(model.device))
        clipped_ratio = torch.clamp(ratio, 1 - clip_param, 1 + clip_param)
        per_token_loss = -torch.min(ratio * advantages, clipped_ratio * advantages)   #loss function
        # per_token_loss = -per_token_loss
        loss += ((per_token_loss * completion_mask).sum(dim=1) / completion_mask.sum(dim=1)).mean()

    return loss


if __name__ == '__main__':
    accelerator = Accelerator()
    episode = 2
    step = 1
    # my_prompt = ['本系统共有20条馈线，275个节点，266条支路，其中179条固定支路，87条灵活支路。节点信息如下：Node=1: voltage=10.1kv; Node=2: voltage=10.073821603507081kv; Node=3: voltage=10.067929323644334kv; Node=4: voltage=10.05501808499724kv; Node=5: voltage=10.034936080179095kv; Node=6: voltage=10.03027285390473kv; Node=7: voltage=10.021969940347093kv; Node=8: voltage=10.014113327142516kv; Node=9: voltage=10.011665507523293kv; Node=10: voltage=10.009485231203163kv; Node=11: voltage=10.058401586154758kv; Node=12: voltage=10.011169230052397kv; Node=13: voltage=10.011665511754346kv; Node=14: voltage=10.1kv; Node=15: voltage=10.080854715687666kv; Node=16: voltage=10.079122065991035kv; Node=17: voltage=10.07800897793283kv; Node=18: voltage=10.075742191724311kv; Node=19: voltage=10.074965741122977kv; Node=20: voltage=10.080534535701071kv; Node=21: voltage=10.080498957351194kv; Node=22: voltage=10.08049895659708kv; Node=23: voltage=10.1kv; Node=24: voltage=10.087301589865332kv; Node=25: voltage=10.071182683744402kv; Node=26: voltage=10.063170008998839kv; Node=27: voltage=10.023342934630664kv; Node=28: voltage=10.020935742486731kv; Node=29: voltage=10.001341335479514kv; Node=30: voltage=9.98690790676209kv; Node=31: voltage=9.974283004593111kv; Node=32: voltage=9.972852677077807kv; Node=33: voltage=9.96764696943998kv; Node=34: voltage=9.95885994574798kv; Node=35: voltage=9.952285910817574kv; Node=36: voltage=9.95204142410857kv; Node=37: voltage=9.951921432533293kv; Node=38: voltage=9.95204142368653kv; Node=39: voltage=9.949592018588977kv; Node=40: voltage=9.949592018778267kv; Node=41: voltage=9.945452648339796kv; Node=42: voltage=9.945452648352953kv; Node=43: voltage=10.1kv; Node=44: voltage=10.082018879226434kv; Node=45: voltage=10.062028585098863kv; Node=46: voltage=10.031806161454993kv; Node=47: voltage=10.015598446261961kv; Node=48: voltage=9.98950369936595kv; Node=49: voltage=9.962936212702303kv; Node=50: voltage=9.937543292308014kv; Node=51: voltage=9.928438718673426kv; Node=52: voltage=9.89513878651725kv; Node=53: voltage=9.889973092440597kv; Node=54: voltage=9.885490986506728kv; Node=55: voltage=9.883784868929991kv; Node=56: voltage=9.88278119930137kv; Node=57: voltage=9.988038842600313kv; Node=58: voltage=9.986870574716152kv; Node=59: voltage=9.927146421376449kv; Node=60: voltage=9.895138786608582kv; Node=61: voltage=10.1kv; Node=62: voltage=10.073487837818952kv; Node=63: voltage=10.02814512615676kv; Node=64: voltage=10.021299359771248kv; Node=65: voltage=9.997587940161056kv; Node=66: voltage=9.99188855542837kv; Node=67: voltage=9.975648313611185kv; Node=68: voltage=9.971680491852048kv; Node=69: voltage=9.96962538680814kv; Node=70: voltage=9.968654237722987kv; Node=71: voltage=9.967063858400374kv; Node=72: voltage=9.966268751649636kv; Node=73: voltage=10.072797453615102kv; Node=74: voltage=10.020389566005516kv; Node=75: voltage=10.02038956778486kv; Node=76: voltage=10.1kv; Node=77: voltage=10.09872029011484kv; Node=78: voltage=10.09648481130354kv; Node=79: voltage=10.095555364157738kv; Node=80: voltage=10.093391999838584kv; Node=81: voltage=10.090463316755198kv; Node=82: voltage=10.09007252878571kv; Node=83: voltage=10.09046331947287kv; Node=84: voltage=10.1kv; Node=85: voltage=10.095454906069977kv; Node=86: voltage=10.086959487962528kv; Node=87: voltage=10.084061345926514kv; Node=88: voltage=10.086022899964242kv; Node=89: voltage=10.090730435396267kv; Node=90: voltage=10.087740954901463kv; Node=91: voltage=10.01265005605731kv; Node=92: voltage=10.012650055321773kv; Node=93: voltage=10.008605178364686kv; Node=94: voltage=10.008237851062871kv; Node=95: voltage=10.005371615268427kv; Node=96: voltage=10.004671687511982kv; Node=97: voltage=9.995557206764715kv; Node=98: voltage=9.994447699526756kv; Node=99: voltage=9.993630207288886kv; Node=100: voltage=10.000150808369046kv; Node=101: voltage=10.000158834846864kv; Node=102: voltage=10.1kv; Node=103: voltage=10.094174267622204kv; Node=104: voltage=10.094020022143546kv; Node=105: voltage=10.094174306472073kv; Node=106: voltage=10.1kv; Node=107: voltage=10.080606882049706kv; Node=108: voltage=10.078195687209002kv; Node=109: voltage=10.05938370344537kv; Node=110: voltage=10.053487105358201kv; Node=111: voltage=10.04989312745236kv; Node=112: voltage=10.03420880375533kv; Node=113: voltage=10.02617108484319kv; Node=114: voltage=10.01671455241823kv; Node=115: voltage=9.996271109690934kv; Node=116: voltage=9.990030621965198kv; Node=117: voltage=9.98686488125161kv; Node=118: voltage=9.987944622326356kv; Node=119: voltage=9.986436083874631kv; Node=120: voltage=9.985886101521647kv; Node=121: voltage=9.98563849291413kv; Node=122: voltage=9.985367268926336kv; Node=123: voltage=9.985559660384226kv; Node=124: voltage=10.05253810251757kv; Node=125: voltage=10.051796227181239kv; Node=126: voltage=9.990030622619754kv; Node=127: voltage=10.1kv; Node=128: voltage=9.93477522774644kv; Node=129: voltage=9.843349796803633kv; Node=130: voltage=9.84334979940279kv; Node=131: voltage=9.820687286901919kv; Node=132: voltage=9.81979130846457kv; Node=133: voltage=9.819556592391306kv; Node=134: voltage=9.81950604753971kv; Node=135: voltage=9.819477313101467kv; Node=136: voltage=9.81947039074947kv; Node=137: voltage=9.801556135109372kv; Node=138: voltage=9.750594768368638kv; Node=139: voltage=9.739316030564865kv; Node=140: voltage=9.71770298243705kv; Node=141: voltage=9.687636974104334kv; Node=142: voltage=9.686766504875754kv; Node=143: voltage=9.682797586463384kv; Node=144: voltage=9.687636975073119kv; Node=145: voltage=9.734240460013767kv; Node=146: voltage=9.734205537047206kv; Node=147: voltage=9.681366523341078kv; Node=148: voltage=9.680717422295603kv; Node=149: voltage=9.680250035250022kv; Node=150: voltage=9.680590225681179kv; Node=151: voltage=9.680590225950894kv; Node=152: voltage=9.680590225749064kv; Node=153: voltage=10.1kv; Node=154: voltage=10.030816642241458kv; Node=155: voltage=10.028979655301981kv; Node=156: voltage=10.022603408116302kv; Node=157: voltage=10.018377031091921kv; Node=158: voltage=9.999970643179438kv; Node=159: voltage=10.031940793607863kv; Node=160: voltage=10.031586813656993kv; Node=161: voltage=9.951266892779525kv; Node=162: voltage=9.953597768173912kv; Node=163: voltage=9.953968134822388kv; Node=164: voltage=9.95451027214232kv; Node=165: voltage=9.95547488093141kv; Node=166: voltage=9.958102523506557kv; Node=167: voltage=9.953968135271547kv; Node=168: voltage=10.1kv; Node=169: voltage=10.069854343145026kv; Node=170: voltage=9.992938355665546kv; Node=171: voltage=9.98619948685368kv; Node=172: voltage=10.01979529896464kv; Node=173: voltage=10.014285726477471kv; Node=174: voltage=10.01416960565042kv; Node=175: voltage=10.012577467746242kv; Node=176: voltage=9.994933328802421kv; Node=177: voltage=9.996114335152082kv; Node=178: voltage=9.993245768950146kv; Node=179: voltage=9.993713451584531kv; Node=180: voltage=9.99518477560729kv; Node=181: voltage=9.992328000793659kv; Node=182: voltage=9.989283688467793kv; Node=183: voltage=9.986514606135973kv; Node=184: voltage=9.992968676788678kv; Node=185: voltage=9.98048073247953kv; Node=186: voltage=9.986902509077076kv; Node=187: voltage=9.985434784682573kv; Node=188: voltage=9.985052760505434kv; Node=189: voltage=9.985052773376939kv; Node=190: voltage=9.98444633111448kv; Node=191: voltage=9.983762242472356kv; Node=192: voltage=9.985143272345669kv; Node=193: voltage=9.985717694982204kv; Node=194: voltage=9.985717703331643kv; Node=195: voltage=10.1kv; Node=196: voltage=10.099999966274662kv; Node=197: voltage=10.1kv; Node=198: voltage=10.073283599956149kv; Node=199: voltage=10.038452206010094kv; Node=200: voltage=10.035062318581364kv; Node=201: voltage=10.003065554335695kv; Node=202: voltage=9.97426383195201kv; Node=203: voltage=9.961264794679789kv; Node=204: voltage=9.958573686076878kv; Node=205: voltage=9.946435960356553kv; Node=206: voltage=9.945411699005785kv; Node=207: voltage=9.927117263427395kv; Node=208: voltage=9.915896576706462kv; Node=209: voltage=9.857849584034811kv; Node=210: voltage=9.842915649066782kv; Node=211: voltage=9.837414243807295kv; Node=212: voltage=9.835642484707547kv; Node=213: voltage=9.83161715675804kv; Node=214: voltage=9.831406900137981kv; Node=215: voltage=9.830974815567089kv; Node=216: voltage=9.830921672681832kv; Node=217: voltage=9.83091010673953kv; Node=218: voltage=9.83087054010241kv; Node=219: voltage=9.973270659873101kv; Node=220: voltage=9.955064986916861kv; Node=221: voltage=9.952543884432997kv; Node=222: voltage=9.949546387625908kv; Node=223: voltage=9.842915651274772kv; Node=224: voltage=10.1kv; Node=225: voltage=10.07467147922965kv; Node=226: voltage=10.060687162463962kv; Node=227: voltage=10.060042721483228kv; Node=228: voltage=10.06005510014128kv; Node=229: voltage=10.070507041435231kv; Node=230: voltage=10.06852049460015kv; Node=231: voltage=10.067844725090998kv; Node=232: voltage=10.067696105170272kv; Node=233: voltage=10.067055186161731kv; Node=234: voltage=10.06784471883558kv; Node=235: voltage=10.1kv; Node=236: voltage=10.099358182892718kv; Node=237: voltage=10.099100593066947kv; Node=238: voltage=10.07448246947173kv; Node=239: voltage=10.069852303869862kv; Node=240: voltage=10.068351647555518kv; Node=241: voltage=10.066997758869597kv; Node=242: voltage=10.066041588009307kv; Node=243: voltage=10.093070526065343kv; Node=244: voltage=10.087562311796187kv; Node=245: voltage=10.087562313426456kv; Node=246: voltage=10.1kv; Node=247: voltage=10.07546426640429kv; Node=248: voltage=10.063014907982728kv; Node=249: voltage=10.054195744844536kv; Node=250: voltage=10.071305987940523kv; Node=251: voltage=10.071305996417712kv; Node=252: voltage=10.1kv; Node=253: voltage=10.096913207730267kv; Node=254: voltage=10.094667177172427kv; Node=255: voltage=10.093212577705387kv; Node=256: voltage=10.090689830239189kv; Node=257: voltage=10.089972812110567kv; Node=258: voltage=10.088006478808735kv; Node=259: voltage=10.087292960870784kv; Node=260: voltage=10.091646844841367kv; Node=261: voltage=10.090124217885762kv; Node=262: voltage=10.090124210747222kv; Node=263: voltage=10.1kv; Node=264: voltage=10.098119865057157kv; Node=265: voltage=10.09811989678786kv; Node=266: voltage=10.087438592091724kv; Node=267: voltage=10.079855706949171kv; Node=268: voltage=10.07985570508776kv; Node=269: voltage=10.1kv; Node=270: voltage=10.031908577859499kv; Node=271: voltage=10.018389039425754kv; Node=272: voltage=10.016657337136486kv; Node=273: voltage=10.016339494539782kv; Node=274: voltage=10.017208107401279kv; Node=275: voltage=10.016657251196268kv; 馈线信息如下，所有馈线节点电压固定为10.1kv：馈线1即节点1,馈线2即节点14,馈线3即节点23,馈线4即节点43,馈线5即节点61,馈线6即节点76,馈线7即节点84,馈线8即节点102,馈线9即节点106,馈线10即节点127,馈线11即节点153,馈线12即节点168,馈线13即节点195,馈线14即节点197,馈线15即节点224,馈线16即节点235,馈线17即节点246,馈线18即节点252,馈线19即节点263,馈线20即节点269,根据上述信息你可以获得当前电网的拓扑等信息']

    my_prompt = ["馈线1：馈线2：请问该控制哪几条馈线上的开关"]      #以列表的形式存放，需要自己设计
    for ep in range(episode):
        model.train()
        batch = {
            "plen": [],
            "rewards": [],
            "inputs": [], #Q和A的ID拼接
            "gen_logps": [],
        }
        for t in range(step):
            step_prompt = [my_prompt[t]]  #必须以列表的形式输入
            model, step_prompt = accelerator.prepare(model, step_prompt)
            prompt_length, rewards, merged_ids, record_logps,step_answer = gen_standard_sample(step_prompt)
            batch["plen"].append(prompt_length)
            batch["rewards"].append(rewards)
            batch["inputs"].append(merged_ids)
            batch["gen_logps"].append(record_logps)
            print(step_answer)

        batch_loss = GRPO_step(batch,step)
        accelerator.backward(batch_loss)
        # 执行优化器的步进
        optimizer.step()
        # 梯度清零
        optimizer.zero_grad()
        # loss = GRPO_step(batch)

    # expanded_prompt = []
    # expanded_prompt.extend([my_prompt] * group_size)
    # decoded_outputs = get_answers(expanded_prompt)

