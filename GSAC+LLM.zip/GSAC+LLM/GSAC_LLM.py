import MISOCP重构 as RE
import switch_pairs_Mask as SPM
import LLM_pairs_Mask as LPM
import pandas as pd
import scipy.io as sio
import random
import itertools
from collections import defaultdict
import numpy as np
import torch
import torch.nn.functional as F
import torch.nn as nn
import copy
from tensorboardX import SummaryWriter
from torch_geometric.nn import GCNConv
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
from pathlib import Path
from accelerate import Accelerator
from peft import LoraConfig, get_peft_model
from torch.optim import AdamW
import re
from torch.cuda.amp import autocast, GradScaler
import os
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:128'


random.seed(228)
np.random.seed(228)
torch.manual_seed(0)

####################################################################################################
# local_model_path = str(Path("~/deepseek70B").expanduser())   # 模型路径
local_model_path = str(Path("~/deepseek-7B-model").expanduser())   # 模型路径
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 检查是否有可用的GPU
# 加载模型和分词器
tokenizer = AutoTokenizer.from_pretrained(local_model_path, local_files_only=True, trust_remote_code=True)

model = AutoModelForCausalLM.from_pretrained(
    local_model_path,
    local_files_only=True,
    trust_remote_code=True,
    torch_dtype=torch.bfloat16,
    device_map="auto"
)

#系统prompt，需要自己设计   下面的system_prompt要改
# system_prompt = """You are a helpful assistant. A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The Assistant first thinks about the reasoning process in the mind and then provides the user with the answer. 你是一个配电网方式编排专家，现在一个系统中包含多条馈线，用户将为你提供节点编号、支路及各节点的电压和功率，安全电压范围在9.5kv-10.5kv之间，请根据用户提供的数据分析该控制拿些馈线上的开关，本任务中共20条馈线，回答的馈线编号必须是一到二十的整数，请直接给我答案,答案括在<answer> </answer> 标记中，即 <answer> 你的答案 </answer> 。无论推理过程如何，你务必给出答案且你的答案格式必须严格按照以下格式：<answer>馈线1、2需要进行转供或者无馈线需要进行转供。</answer>"""
system_prompt = """你是一个配电网方式编排专家，现在一个系统中包含多条馈线，用户将为你提供节点编号、支路及各节点的电压和功率，安全电压范围在9.5kv-10.5kv之间，请根据用户提供的数据分析该控制拿些馈线上的开关，本任务中共20条馈线，回答的馈线编号必须是一到二十的整数，请直接给我答案,答案括在<answer> </answer> 标记中，即 <answer> 你的答案 </answer> 。无论推理过程如何，你务必给出答案且你的答案格式必须严格按照以下格式：<answer>馈线1、2需要进行转供或者无馈线需要进行转供。</answer>"""

#微调及训练参数config
optimizer = AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=1e-4)
num_pre_Q = 1
clip_param = 0.2
generation_config = GenerationConfig(
            max_new_tokens=512,  # 变大
            do_sample=True, temperature = 0.9,
            num_return_sequences = num_pre_Q,
            pad_token_id=tokenizer.pad_token_id,)

lora_config = LoraConfig(
    r=8,  # rank for low-rank adaptation (通常为8或16)
    lora_alpha=12,  # LoRA超参数
    lora_dropout=0.1,  # LoRA的dropout率，通常为0.1
    task_type='CAUSAL_LM',  # 任务类型
)
# 应用 LoRA 到模型
model = get_peft_model(model, lora_config)

def gen_answers(prompts):
    # print(f"使用 {torch.cuda.device_count()} 个 GPU!")
    tip_text = []
    for x in prompts:
        tip_text.append(tokenizer.apply_chat_template([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True))
    tip_inputs = tokenizer(tip_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)
    prompt_length = tip_inputs["input_ids"].shape[-1]     #问题的长度
    tip_inputs = {k: v.to(model.device) for k, v in tip_inputs.items()}
    with torch.inference_mode():
        tip_completion_ids = model.generate(**tip_inputs, generation_config=generation_config)
    completion_ids = tip_completion_ids[:, prompt_length:]
    answers = [tokenizer.decode(x).replace('<｜end▁of▁sentence｜>', '') for x in completion_ids]
    return answers

def gen_samples(prompts):
    answers = gen_answers(prompts)    #根据prompt获得答案，比如得到了4个answers
    # if len(answers) == 0: return None, None, None, None
    rewards = []
    for a in answers:
        rewards.append(reward_function(a))
    prompts_text = [tokenizer.apply_chat_template([
             {"role": "system", "content": system_prompt},
             {"role": "user", "content": x}], tokenize=False, add_generation_prompt=True) for x in prompts]
    prompt_inputs = tokenizer(prompts_text, return_tensors="pt", padding=True, padding_side="left", add_special_tokens=False)["input_ids"]
    output_ids = tokenizer(answers, return_tensors="pt", padding=True, padding_side="right", add_special_tokens=False)["input_ids"]
    return prompt_inputs, output_ids, torch.tensor(rewards, dtype=torch.float32), answers #输出prompt对应的ID，答案对应的ID，还有answer

#————————————————————————————————————！！！奖励函数定义,实际控制效果————————————————————————————————#
def reward_function(answer):
    reward=2
    all_answers = re.findall(r"<answer>(.*?)</answer>", answer)
    if not all_answers:
        reward=reward-1
    # 用列表解析提取每一部分中的阿拉伯数字，若无数字则返回空集 []
    all_numbers = [list(map(int, re.findall(r"\d+", answer))) if re.search(r"\d+", answer) else [] for answer in all_answers]
    found_gt_20 = any(num > 20 for sublist in all_numbers for num in sublist)
    if found_gt_20:
        reward=reward-1

    return reward

def get_per_token_logps(logits, input_ids):
    per_token_logps = []  # Use a loop to reduce memory peak.
    for logits_row, input_ids_row in zip(logits, input_ids):
        log_probs = logits_row.log_softmax(dim=-1)
        token_log_prob = torch.gather(log_probs, dim=1, index=input_ids_row.unsqueeze(1)).squeeze(1)
        per_token_logps.append(token_log_prob)
    return torch.stack(per_token_logps)

def gen_standard_sample(prompts): #生成每种prompt样本的结果，然后把不同的prompts存放到一个batch里面，batch是一个字典
    prompt_inputs, output_ids, rewards, answers = gen_samples(prompts)
    # if (rewards.max() - rewards.min()).item() < 0.01:
    #     continue  # 如果奖励的方差很小，跳过
    # 标准化奖励  changed temporarily
    # rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-4)
    # 计算每个问题重复次数，确保输入与输出数量一致
    rep = output_ids.shape[0] // prompt_inputs.shape[0]
    prompt_length = prompt_inputs.shape[1]
    Qrep = prompt_inputs.repeat(1, rep).view(-1, prompt_length)
    # 合并输入和输出
    merged_ids = torch.cat([Qrep, output_ids], dim=1)  #输入Q和输出A拼接
    # 计算其log
    with torch.inference_mode():
        mids = merged_ids.to(model.device)   #输入Q+输出A=input,数据转移到GPU
        gen_logps = get_per_token_logps(model(mids).logits[:, :-1, :], mids[:, 1:])
        record_logps = gen_logps[:, prompt_length - 1:].cpu()     #获取样本的概率分布
    return prompt_length, rewards, merged_ids, record_logps,answers       #返回奖励，合并的ID，以及每个合并ID的log分布

def GRPO_step(batch,step):
    loss = 0
    for t in range(step):
        prompt_length = torch.tensor(batch['plen'][t]).to(model.device)
        inputs = batch['inputs'][t].to(model.device)
        advantages = (batch['rewards'][t].unsqueeze(1)).to(model.device)  # normalized in generation
        logits = model(inputs).logits
        logits = logits[:, :-1, :]  # (B, L-1, V), exclude the last logit: it corresponds to the next token pred
        input_ids = inputs[:, 1:]  # (B, L-1), exclude the first input ID since we don't have logits for it
        per_token_logps = get_per_token_logps(logits, input_ids)
        per_token_logps = per_token_logps[:, prompt_length - 1:]
        completion_mask = (inputs[:, prompt_length:] != tokenizer.pad_token_id).int()
        ratio = torch.exp(per_token_logps - batch['gen_logps'][t].to(model.device))
        clipped_ratio = torch.clamp(ratio, 1 - clip_param, 1 + clip_param)
        per_token_loss = -torch.min(ratio * advantages, clipped_ratio * advantages)   #loss function
        # per_token_loss = -per_token_loss
        loss += ((per_token_loss * completion_mask).sum(dim=1) / completion_mask.sum(dim=1)).mean()
    return loss

def extract_numbers_from_all_answers(text_list):
    # 提取列表中的第一个元素（语段字符串）
    text = text_list[0] if isinstance(text_list, list) and len(text_list) > 0 else ""
    # 匹配所有 <answer>XXXX</answer> 部分
    all_answers = re.findall(r"<answer>(.*?)</answer>", text)

    # 提取阿拉伯数字，若无数字则返回空集 []，并且过滤掉大于 20 的数字
    all_numbers = [
        [num for num in map(int, re.findall(r"\d+", answer)) if num <= 20]
        if re.search(r"\d+", answer) else []
        for answer in all_answers
    ]
    # 保证 all_numbers 长度为 4，如果不足则补充空集 []，如果超出则截取前四个
    if len(all_numbers) < num_pre_Q:
        all_numbers.extend([[]] * (num_pre_Q - len(all_numbers)))  # 补充空集 []
    else:
        all_numbers = all_numbers[:num_pre_Q]  # 截取前四个
    return all_numbers
####################################################################################################

class PolicyNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim,node_feature,NUM_STATE_expand):
        super(PolicyNet, self).__init__()
        self.conv1 = GCNConv(node_feature, 4).to(device)
        self.fc1 = torch.nn.Linear(NUM_STATE_expand, hidden_dim)
        self.fc1.weight.data.normal_(0, 0.1)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc2.weight.data.normal_(0, 0.1)
        self.fc3 = torch.nn.Linear(hidden_dim, action_dim)
        self.fc3.weight.data.normal_(0, 0.1)
        self.tanh = nn.Tanh().to(device)

    def forward(self, x,edge_index):
        x = x.view(x.size(0), 275, 4)
        x = self.conv1(x, edge_index).to(device)
        x = self.tanh(x)
        x = x.view(x.size(0), -1)  # (展开特征)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return F.softmax(self.fc3(x), dim=1)

class QValueNet(torch.nn.Module):
    def __init__(self, state_dim, hidden_dim, action_dim,node_feature,NUM_STATE_expand):
        super(QValueNet, self).__init__()
        self.conv1 = GCNConv(node_feature, 4).to(device)
        self.fc1 = torch.nn.Linear(NUM_STATE_expand, hidden_dim)
        self.fc1.weight.data.normal_(0, 0.1)
        self.fc2 = torch.nn.Linear(hidden_dim, hidden_dim)
        self.fc2.weight.data.normal_(0, 0.1)
        self.fc3 = torch.nn.Linear(hidden_dim, action_dim)
        self.fc3.weight.data.normal_(0, 0.1)
        self.tanh = nn.Tanh().to(device)

    def forward(self, x,edge_index):
        x = x.view(x.size(0), 275, 4)
        x = self.conv1(x, edge_index).to(device)
        x = self.tanh(x)
        x = x.view(x.size(0), -1)  # (展开特征)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

class SAC:
    ''' 处理离散动作的SAC算法 '''
    def __init__(self, state_dim, hidden_dim, action_dim, actor_lr, critic_lr,
                 alpha_lr, target_entropy, tau, gamma, MEMORY_CAPACITY, script_name, device,
                 node_feature, hidden_size, NUM_STATE_expand,NUM_EDGE,BATCH_SIZE):
        # 图网络
        self.node_feature =node_feature
        self.hidden_size = hidden_size
        self.NUM_STATE_expand = NUM_STATE_expand
        self.NUM_EDGE=NUM_EDGE
        # 策略网络
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden_dim=hidden_dim
        self.BATCH_SIZE=BATCH_SIZE

        self.actor = PolicyNet(state_dim, hidden_dim, action_dim,node_feature,NUM_STATE_expand).to(device)
        # 第一个Q网络
        self.critic_1 = QValueNet(state_dim, hidden_dim, action_dim,node_feature,NUM_STATE_expand).to(device)
        # 第二个Q网络
        self.critic_2 = QValueNet(state_dim, hidden_dim, action_dim,node_feature,NUM_STATE_expand).to(device)
        self.target_critic_1 = QValueNet(state_dim, hidden_dim,action_dim,node_feature,NUM_STATE_expand).to(device)  # 第一个目标Q网络
        self.target_critic_2 = QValueNet(state_dim, hidden_dim,action_dim,node_feature,NUM_STATE_expand).to(device)  # 第二个目标Q网络
        # 令目标Q网络的初始参数和Q网络一样
        self.target_critic_1.load_state_dict(self.critic_1.state_dict())
        self.target_critic_2.load_state_dict(self.critic_2.state_dict())
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(),lr=actor_lr)
        self.critic_1_optimizer = torch.optim.Adam(self.critic_1.parameters(),lr=critic_lr)
        self.critic_2_optimizer = torch.optim.Adam(self.critic_2.parameters(),lr=critic_lr)
        # 使用alpha的log值,可以使训练结果比较稳定
        self.log_alpha = torch.tensor(np.log(0.01), dtype=torch.float)
        self.log_alpha.requires_grad = True  # 可以对alpha求梯度
        self.log_alpha_optimizer = torch.optim.Adam([self.log_alpha],lr=alpha_lr)
        self.target_entropy = target_entropy  # 目标熵的大小
        self.gamma = gamma
        self.tau = tau
        self.device = device
        self.memory_counter = 0
        self.MEMORY_CAPACITY = MEMORY_CAPACITY
        self.memory = np.zeros((self.MEMORY_CAPACITY, self.state_dim * 2 + self.NUM_EDGE *4 + 2))
        self.script_name = script_name
        self.directory = './exp' + self.script_name + '/'
        self.writer = SummaryWriter(self.directory)

    def apply_mask(self, probs, switch_mask):
        # 将 probs 展平为一维向量
        probs = probs.view(-1)  # 形状变为 [2013,]
        # 创建 switch_mask 和 OLTC_mask 的布尔掩码
        switch_mask = switch_mask.view(-1).to(torch.bool)  # 转换为布尔型
        masked_probs = probs * switch_mask.float()
        # 去除负值
        masked_probs = torch.clamp(masked_probs, min=0)
        # 重新归一化概率分布
        if masked_probs.sum() > 0:
            masked_probs = masked_probs / (masked_probs.sum() + 1e-15)  # 防止除以零
        else:
            masked_probs = torch.ones_like(masked_probs) / masked_probs.numel()
        return masked_probs

    def take_action(self, state, current_edges, switch_pairs, flexible_list, feeder_list,feeder_per,edge_index,flag):
        if flag==1:
            switch_mask = LPM.switch_pairs_Mask_main(current_edges, switch_pairs, flexible_list, feeder_list,feeder_per)
            switch_mask = torch.tensor(switch_mask, dtype=torch.float32).to(self.device)
        if flag==0:
            switch_mask = SPM.switch_pairs_Mask_main(current_edges, switch_pairs, flexible_list, feeder_list)
            switch_mask = torch.tensor(switch_mask, dtype=torch.float32).to(self.device)

        state = state.to(self.device)
        probs = self.actor(state,edge_index)
        masked_probs = self.apply_mask(probs, switch_mask).to(torch.float32).to(self.device)

        if masked_probs.sum() > 0:
            masked_probs = masked_probs / (masked_probs.sum() + 1e-15)  # 防止除以零
        else:
            # 如果所有值为零，则使用均匀分布
            masked_probs = torch.ones_like(masked_probs) / masked_probs.numel()

        masked_probs = masked_probs.squeeze()  # 变成 (n,)
        # print(masked_probs)
        action_dist = torch.distributions.Categorical(masked_probs)
        action = action_dist.sample()
        return action.item()  # 策略网络输出

    # 计算目标Q值,直接用策略网络的输出概率进行期望计算
    def calc_target(self, rewards, next_states,edge_index):
        next_probs = self.actor(next_states,edge_index)        #下一个动作的概率分布
        next_log_probs = torch.log(next_probs + 1e-8)
        entropy = -torch.sum(next_probs * next_log_probs, dim=1, keepdim=True)
        q1_value = self.target_critic_1(next_states,edge_index)
        q2_value = self.target_critic_2(next_states,edge_index)
        min_qvalue = torch.sum(next_probs * torch.min(q1_value, q2_value),dim=1,keepdim=True)
        next_value = min_qvalue + self.log_alpha.exp() * entropy
        td_target = rewards + self.gamma * next_value
        return td_target

    def soft_update(self, net, target_net):
        for param_target, param in zip(target_net.parameters(),net.parameters()):
            param_target.data.copy_(param_target.data * (1.0 - self.tau) + param.data * self.tau)

    def store_transition(self, state, edge, action, reward, next_state, next_edge):
        # print(type(state),type(action))
        if type(state) == torch.Tensor:
            state = state.cpu().detach().numpy() # []
        if type(edge) == torch.Tensor:
            edge = edge.cpu().detach().numpy()  #  []
        action = action
        if type(next_state) == torch.Tensor:
            next_state = next_state.cpu().detach().numpy()  # []
        if type(next_edge) == torch.Tensor:
            next_edge = next_edge.cpu().detach().numpy()   # []
        transition = np.hstack((state, edge, [action], [reward], next_state,next_edge))
        index = self.memory_counter % self.MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.memory_counter += 1

    def learn(self,edge_index):
        sample_index = np.random.choice(self.MEMORY_CAPACITY, batch_size)
        batch_memory = self.memory[sample_index, :]

        batch_state = torch.FloatTensor(batch_memory[:, :self.state_dim]).to(device)  # tensor(64,33)
        batch_edge = torch.FloatTensor(batch_memory[:, self.state_dim: self.state_dim + 2 * self.NUM_EDGE]).to(device)  # tensor(64,64)
        batch_action = torch.LongTensor(batch_memory[:, self.state_dim + 2 * self.NUM_EDGE:self.state_dim + 2 * self.NUM_EDGE + 1].astype(int)).to(device)
        batch_reward = torch.FloatTensor(batch_memory[:, self.state_dim + 2 * self.NUM_EDGE + 1: self.state_dim + 2 * self.NUM_EDGE + 2]).to( device)
        batch_next_state = torch.FloatTensor(batch_memory[:, self.state_dim + 2 * self.NUM_EDGE + 2: 2 * self.state_dim + 2 * self.NUM_EDGE + 2]).to(device)
        batch_next_edge = torch.FloatTensor(batch_memory[:, -2 * self.NUM_EDGE:]).to(device)

        reshaped_batch_state = torch.unsqueeze(batch_state, dim=2)  # (32,33,1)
        reshaped_batch_edge = batch_edge.view(self.BATCH_SIZE, 2, self.NUM_EDGE).long()  # (32,2,32)
        reshaped_batch_next_edge = batch_next_edge.view(self.BATCH_SIZE, 2, self.NUM_EDGE).long()  # (32,2,32)
        reshaped_batch_next_state = torch.unsqueeze(batch_next_state, dim=2)  # (32,33,1)

        # 更新两个Q网络
        v_td_target=[]
        v_critic_1_q_values=[]
        v_critic_2_q_values=[]

        for batch_x, batch_edge_index, batch_edge_index_, batch_x_, action, reward in zip(reshaped_batch_state,reshaped_batch_edge,reshaped_batch_next_edge,reshaped_batch_next_state,batch_action, batch_reward):
            v0_td_target = self.calc_target(batch_reward, batch_next_state, edge_index)  #
            v0_critic_1_q_values = self.critic_1(batch_state, edge_index).gather(1, batch_action)  #
            v0_critic_2_q_values = self.critic_2(batch_state, edge_index).gather(1, batch_action)  #
            v0_q1_value = self.critic_1(batch_state, edge_index).gather(1, batch_action)  #
            v0_q2_value = self.critic_2(batch_state, edge_index).gather(1, batch_action)  #
            v_td_target.append(v0_td_target)
            v_critic_1_q_values.append(v0_critic_1_q_values)
            v_critic_2_q_values.append(v0_critic_2_q_values)

        stacked_v_td_target = torch.cat(v_td_target, dim=0)
        stacked_v_critic_1_q_values =torch.cat(v_critic_1_q_values, dim=0)
        stacked_v_critic_2_q_values = torch.cat(v_critic_2_q_values, dim=0)
        critic_1_loss = torch.mean(F.mse_loss(stacked_v_critic_1_q_values, stacked_v_td_target))
        critic_2_loss = torch.mean(F.mse_loss(stacked_v_critic_2_q_values, stacked_v_td_target))
        self.critic_1_optimizer.zero_grad()
        critic_1_loss.backward(retain_graph=True)
        self.critic_1_optimizer.step()
        self.critic_2_optimizer.zero_grad()
        critic_2_loss.backward(retain_graph=True)
        self.critic_2_optimizer.step()

        # 更新策略网络  actor
        probs = self.actor(batch_state,edge_index)
        log_probs = torch.log(probs + 1e-8)
        # 直接根据概率计算熵
        entropy = -torch.sum(probs * log_probs, dim=1, keepdim=True)  #
        q1_value = self.critic_1(batch_state,edge_index)
        q2_value = self.critic_2(batch_state,edge_index)
        min_qvalue = torch.sum(probs * torch.min(q1_value, q2_value), dim=1, keepdim=True)  # 直接根据概率计算期望
        actor_loss = torch.mean(-self.log_alpha.exp() * entropy - min_qvalue)
        self.actor_optimizer.zero_grad()
        actor_loss.backward(retain_graph=True)
        self.actor_optimizer.step()

        # 更新alpha值
        alpha_loss = torch.mean((entropy - self.target_entropy).detach() * self.log_alpha.exp())
        self.log_alpha_optimizer.zero_grad()
        alpha_loss.backward(retain_graph=True)
        self.log_alpha_optimizer.step()
        self.soft_update(self.critic_1, self.target_critic_1)
        self.soft_update(self.critic_2, self.target_critic_2)

    def save(self):
        torch.save(self.actor.state_dict(), self.directory + 'evalC.pth')

    def load(self):
        self.actor.load_state_dict(torch.load(self.directory + 'evalC.pth'))

def reset(t, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv):
    voltage, Pload, Qload, PPV, tp, _ = RE.MISOCP(t, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
    ###############################################
    numm = 0
    text1 = ""
    text1 = text1 + '本系统共有20条馈线，275个节点，266条支路，其中179条固定支路，87条灵活支路。节点信息如下：'
    for i in range(0, 275):
        text1 = text1 + ("Node={}: voltage={}kv, loadP={}MW, loadQ={}MVar,PVmax={}MW; ".format(i + 1,
                                        voltage[0, i] * 10,Pload[0, i] * 10,Qload[0, i] * 10,PPV[0, i] * 10))
    for i in range(0, 275):
        text1 = text1 + ("Node={}: voltage={}kv; ".format(i + 1, voltage[0, i] * 10))
    text1 = text1 + '支路信息如下,其中status=1.0表示支路闭合，status=0.0表示支路断开：'
    for i, j in edge_list:
        text1 = text1 + ("Line={}: status={}; ".format((i, j), tp[0, numm]))
        numm += 1
    text1 = text1 + '灵活支路如下：'
    for i, j in flexible_list:
        text1 = text1 + ("flexible_Line={}: ".format((i, j)))
    text1 = text1 + '馈线信息如下，所有馈线节点电压固定为{}kv：'.format(root_fixv * 10)
    for i in range(0, 20):
        text1 = text1 + '馈线{}即节点{},'.format(i + 1, feeders_list[i])
    text1 = text1 + '根据上述信息你可以获得当前电网的拓扑等信息，根据以上信息，请问该控制哪几条馈线上的开关。'
    prompt0 = [text1]
    ###############################################
    ##############################################################################
    min_val = 0.9
    max_val = 1.05
    voltage2 = (voltage - min_val) / (max_val - min_val)
    min_power = 0
    max_power = 2.3
    Pload = (Pload - min_power) / (max_power - min_power)
    Qload = (Qload - min_power) / (max_power - min_power)
    PPV = (PPV - min_power) / (max_power - min_power)
    ##############################################################################
    voltage = torch.from_numpy(voltage).float()
    voltage2 = torch.from_numpy(voltage2).float()
    Pload = torch.from_numpy(Pload).float()
    Qload = torch.from_numpy(Qload).float()
    PPV = torch.from_numpy(PPV).float()
    tp = torch.from_numpy(tp).float()
    gridstate = torch.cat((voltage, Pload, Qload, PPV), dim=1)
    return gridstate,prompt0,voltage

def step(t, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv):
    voltage, Pload, Qload, PPV, tp, obj = RE.MISOCP(t, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
    ##############################################################################
    min_val = 0.9
    max_val = 1.05
    voltage = (voltage - min_val) / (max_val - min_val)
    min_power = 0
    max_power = 2.3
    Pload = (Pload - min_power) / (max_power - min_power)
    Qload = (Qload - min_power) / (max_power - min_power)
    PPV = (PPV - min_power) / (max_power - min_power)
    ##############################################################################
    voltage = torch.from_numpy(voltage).float()
    Pload = torch.from_numpy(Pload).float()
    Qload = torch.from_numpy(Qload).float()
    PPV = torch.from_numpy(PPV).float()
    tp = torch.from_numpy(tp).float()
    gridstate = torch.cat((voltage, Pload, Qload, PPV), dim=1)
    return gridstate, -10*obj

def generate_switch_pairs(N):
    switch_pairs = []
    # (0, 0) 表示不做改动，加入到列表中
    switch_pairs.append((0, 0))
    # 生成所有可能的开关对 (s, j)，但排除 (s, s) 的情况
    for s, j in itertools.product(range(1, N + 1), repeat=2):
        if s != j:  # 排除 (s, s) 的情况
            switch_pairs.append((s, j))
    return switch_pairs

def analysis1(voltage,feeders_list,current_edges):
    # voltage = voltage*1.04
    voltage = voltage.tolist()
    voltage = voltage[0]
    graph = defaultdict(list)
    for u, v in current_edges:
        graph[u].append(v)
        graph[v].append(u)
    # 通过BFS为每条馈线标记节点
    node_to_feeder = {}  # 记录节点所属的馈线编号（1-20）
    for feeder_id, root in enumerate(feeders_list, start=1):  # 馈线编号从1到20
        if root not in graph:
            continue
        visited = set()
        queue = [root]
        while queue:
            node = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            node_to_feeder[node] = feeder_id  # 标记节点所属馈线
            for neighbor in graph[node]:
                if neighbor not in visited:
                    queue.append(neighbor)
    # 找出电压异常的节点
    invalid_nodes = [i + 1 for i, v in enumerate(voltage) if v > 1.05 or v < 0.95]
    # 关联异常节点与馈线
    invalid_feeders = set()  # 使用集合存储存在异常节点的馈线编号
    for node in invalid_nodes:
        feeder = node_to_feeder.get(node)
        if feeder:
            invalid_feeders.add(feeder)

    # 整理结果：将所有存在异常节点的馈线编号排序
    result = sorted(invalid_feeders)  # 排序并转换为列表
    return result  # 返回格式为 [馈线1, 馈线2, ...]



if __name__ == '__main__':
    # -----------------------------------------数据加载————————————————————————————————————————————#
    path = '20_feeder_improve.xlsx'
    bus_data = pd.read_excel(path, sheet_name='bus')  # 索引从0开始
    edge_data = pd.read_excel(path, sheet_name='branch')  # branch参数
   # fixed_edge = pd.read_excel(path, sheet_name='fixed_branch')  # 固定支路
    control_edge = pd.read_excel(path, sheet_name='contrable_branch') # 可控制路
    pv_data = pd.read_excel(path, sheet_name='pv_capacity')  # PV接入节点、容量
    curve = pd.read_excel(path, sheet_name='pv_load_curve')  # PV\load曲线
    origin_edge = pd.read_excel(path, sheet_name='origin')

    edge_list = []
    for i in range(len(edge_data)):  # 边的数量  所有支路
        temp = edge_data.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        edge_list.append((start_bus, end_bus))  # 把支路提取出来

    flexible_list = []
    for i in range(len(control_edge)):  # 边的数量
        temp = control_edge.iloc[i]  # 获取表格中第i行数据
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        flexible_list.append((start_bus, end_bus))  # 把支路提取出来

    fixed_list = []
    for (start_bus, end_bus) in edge_list:
        if (start_bus, end_bus) not in flexible_list:
            fixed_list.append((start_bus, end_bus))


    origin_list = []
    for i in range(len(origin_edge)):
        temp = origin_edge.iloc[i]
        start_bus = int(temp.iloc[0])
        end_bus = int(temp.iloc[1])
        origin_list.append((start_bus, end_bus))

    p_load = {}
    q_load = {}
    for i in range(len(bus_data)):
        temp_load = bus_data.iloc[i]  # 第i行
        bus = i
        p_load[bus] = temp_load.iloc[1]/10000/1.5  # 标幺 减小负荷
        q_load[bus] = temp_load.iloc[2]/10000/1.5  # 标幺

    pv_list = []
    pv = {}
    all_bus_list = list(range(1, 276))
    for i in range(len(pv_data)):
        temp = pv_data.iloc[i]  # 获取表格中第i行数据
        pv_bus_index = int(temp.iloc[0])  # 光伏安装节点编号
        pv_list.append(pv_bus_index)
        pv_capacity = temp.iloc[1]/10
        pv[pv_bus_index] = pv_capacity
    no_pv_bus = list(set(all_bus_list) - set(pv_list))
    pv_curve = curve.iloc[:, 2]
    load_curve = curve.iloc[:, 1]

    # print(len(edge_list),len(fixed_list),len(flexible_list),len(origin_list),len(pv_list),len(no_pv_bus))
    N = len(flexible_list)
    switch_pairs = generate_switch_pairs(N)

    actor_lr = 0.0001
    critic_lr = 0.0003
    alpha_lr = 0.0003
    state_dim = len(bus_data)*4  # Ui Pload Qload PPV
    action_DN = (N*N - N+1)
    action_dim = action_DN
    hidden_dim = 128
    gamma = 0.99
    tau = 0.005  # 软更新参数
    batch_size = 16
    target_entropy = -1
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    print(device)

    MEMORY_CAPACITY = 5000  # ,5000

    N = len(flexible_list)
    switch_pairs = generate_switch_pairs(N)

    true_agent = SAC(state_dim=state_dim, hidden_dim=hidden_dim, action_dim=action_dim, actor_lr=actor_lr,
                     critic_lr=critic_lr, alpha_lr=alpha_lr,
                     target_entropy=target_entropy, tau=tau, gamma=gamma, MEMORY_CAPACITY=MEMORY_CAPACITY,
                     script_name='true_SAC', device=device,
                     node_feature=4, hidden_size=3, NUM_STATE_expand=4*275, NUM_EDGE=2*len(origin_list), BATCH_SIZE=batch_size)

    mode = 'train'
    if mode == 'train':
        accelerator = Accelerator()
        feeders_list=  [1,14,23,43,61,76,84,102,106,127,153,168,195,197,224,235,246,252,263,269]
        epochs = 800 # 500
        episodes = 17 # 23
        root_fixv = 1.02
        reward_multi = np.zeros((1, epochs))

        for h in range(epochs):
            # ——————————————————————————————————————————初始化状态——————————————————————————————————————————————#
            begin = 0  # 开始时间点
            rr=0

            current_edges = copy.deepcopy(origin_list)
            action_edges = copy.deepcopy(current_edges)
            grid_state,step_prompt,vv=reset(begin, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
            model.train()
            batch = {
                "plen": [],
                "rewards": [],
                "inputs": [],  # Q和A的ID拼接
                "gen_logps": [],
            }
            # print(step_prompt)

            # print(grid_state,grid_state.shape)  # torch.Size([1, 1366])
            aj1_tensor = torch.zeros((1, 275 - 20))
            aj2_tensor = torch.zeros((1, 275 - 20))
            for j in range(275-20):  # 原始状态的邻阶矩阵
                aj1_tensor[0, j] = origin_list[j][0] - 1  # 邻接矩阵需要从0开始
                aj2_tensor[0, j] = origin_list[j][1] - 1
            result_tensor_vertical = torch.cat((aj1_tensor, aj2_tensor), dim=0)
            result_tensor_vertical_convert = torch.cat((aj2_tensor, aj1_tensor), dim=0)
            result_tensor_vertical_expand = torch.cat((result_tensor_vertical, result_tensor_vertical_convert), dim=1)

            result_tensor_horizental = torch.cat((aj1_tensor, aj2_tensor), dim=1)  # 存入经验回放[shou,mo]
            result_tensor_horizental_convert = torch.cat((aj2_tensor, aj1_tensor), dim=1)  # 存入经验回放[mo,shou]
            result_tensor_horizental_expand = torch.cat((result_tensor_horizental, result_tensor_horizental_convert),dim=1)

            result_tensor_horizental_expand = result_tensor_horizental_expand.long().to(device)
            result_tensor_horizental_expand = result_tensor_horizental_expand.squeeze()  # (128,)存入经验回放池
            linjie_matrix = result_tensor_vertical_expand.long().to(device)  # 无向图临接矩阵

            for tt in range(episodes):
                r_k_list = []
                action_k_list = []

                model, step_prompt = accelerator.prepare(model, step_prompt)
                prompt_length, reward_LLM, merged_ids, record_logps, step_answer = gen_standard_sample(step_prompt)
                # print(reward_LLM)

                #### 根据step_answer假设得到了哪些馈线  ####
                answer_feeder0 = analysis1(vv, feeders_list, current_edges)
                answer_feeder=extract_numbers_from_all_answers(step_answer)
                # print(answer_feeder)
                # answer_feeder = [[11, 5, 17, 18, 10, 20, 12, 1], [1, 9, 8, 19], [9, 11, 12],[3, 4, 18, 1, 8, 11, 7, 12, 20, 2]]
                # answer_feeder = [[],[],[],[]]

                # for k in range(0, num_pre_Q):  #
                #     action_edges_k = copy.deepcopy(action_edges)
                #     answer_feeder_per = answer_feeder[k]
                #     answer_feeder = answer_feeder+ answer_feeder0
                #     if answer_feeder_per == []:
                #         flag=0  #
                #     else: flag=1
                #     action = true_agent.take_action(grid_state, current_edges, switch_pairs, flexible_list,feeders_list, answer_feeder_per,linjie_matrix,flag)
                #     action_switch = action
                #     # print(h,tt,k,action_switch)
                #     if (action_switch == 0):
                #         # current_edges = action_edges
                #         grid_state_k, r_k = step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve,current_edges, root_fixv)
                #         r_k_list.append(r_k)
                #         action_k_list.append(action_switch)
                #
                #     elif ((flexible_list[switch_pairs[action_switch][0] - 1] in current_edges) and (flexible_list[switch_pairs[action_switch][1] - 1] not in current_edges)):
                #         action_edges_k.remove(flexible_list[switch_pairs[action_switch][0] - 1])
                #         action_edges_k.append(flexible_list[switch_pairs[action_switch][1] - 1])
                #         grid_state_k, r_k = step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve,action_edges_k, root_fixv)
                #         # current_edges = action_edges
                #         r_k = r_k - 0.1  # 动作成本
                #         r_k_list.append(r_k)
                #         action_k_list.append(action_switch)
                #
                #     else:
                #         grid_state_k, r_k = np.zeros((1, 1100)), -100  # 直接选择了不满足安全约束的动作
                #
                # max_index = r_k_list.index(max(r_k_list))
                # action_switch = action_k_list[max_index]
                # # print(r_k_list,action_k_list,action_switch)
                # r_k_list = []
                # action_k_list = []
                ########################
                answer_feeder_per = answer_feeder[0]
                answer_feeder = answer_feeder + answer_feeder0

                if answer_feeder_per == []:
                    flag = 0  #
                else:
                    flag = 1
                action = true_agent.take_action(grid_state, current_edges, switch_pairs, flexible_list, feeders_list,
                                                answer_feeder_per, linjie_matrix, flag)
                action_switch = action
                ########################
                # print(action_switch)
                if (action_switch == 0):
                    current_edges = action_edges
                    grid_state_, r = step(begin+tt, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)

                elif ((flexible_list[switch_pairs[action_switch][0] - 1] in current_edges) and (flexible_list[switch_pairs[action_switch][1] - 1] not in current_edges)):
                    action_edges.remove(flexible_list[switch_pairs[action_switch][0] - 1])
                    action_edges.append(flexible_list[switch_pairs[action_switch][1] - 1])
                    current_edges = action_edges
                    grid_state_, r = step(begin+tt, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
                    r = r - 0.1  # 动作成本

                else:
                    grid_state_, r = np.zeros((1, 1100)), -30  # 直接选择了不满足安全约束的动作

                aj1_tensor = torch.zeros((1, 275-20))
                aj2_tensor = torch.zeros((1, 275-20))

                for j in range(275-20):  # 选出动作后的邻阶矩阵
                    aj1_tensor[0, j] = action_edges[j][0] - 1  # 邻接矩阵需要从0开始
                    aj2_tensor[0, j] = action_edges[j][1] - 1
                state_tensor_update = torch.cat((aj1_tensor, aj2_tensor), dim=0)
                state_tensor_update_convert = torch.cat((aj2_tensor, aj1_tensor), dim=0)
                result_tensor_update_expand = torch.cat((state_tensor_update, state_tensor_update_convert), dim=1)

                state_tensor_update_horizental = torch.cat((aj1_tensor, aj2_tensor), dim=1)  # [首,末]
                state_tensor_update_horizental_convert = torch.cat((aj2_tensor, aj1_tensor), dim=1)  # [末,首]
                state_tensor_update_expand = torch.cat((state_tensor_update_horizental, state_tensor_update_horizental_convert), dim=1)

                state_tensor_update_expand = state_tensor_update_expand.long().to(device)
                state_tensor_update_expand = state_tensor_update_expand.squeeze()
                linjie_matrix = result_tensor_update_expand.long().to(device)  # 更新临接矩阵


                r=r/3
                reward_LLM=reward_LLM/2
                reward_LLM=reward_LLM.cpu().detach().numpy()
                grid_state = grid_state.squeeze()
                grid_state_ = grid_state_.squeeze()
                true_agent.store_transition(grid_state,result_tensor_horizental_expand, action, r, grid_state_,state_tensor_update_expand)
                rr = rr + r+reward_LLM[0]
                print(h, tt, action_switch, r+reward_LLM[0])
                result_tensor_horizental_expand = state_tensor_update_expand  # 更新拓扑结构
                if true_agent.memory_counter >= 2:  # 2
                    true_agent.learn(linjie_matrix)
                true_agent.save()
                grid_state,step_prompt,vv=reset(begin+tt+1, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)

                batch["plen"].append(prompt_length)
                batch["rewards"].append(r+reward_LLM)
                batch["inputs"].append(merged_ids)
                batch["gen_logps"].append(record_logps)
                torch.cuda.empty_cache()

            reward_multi[0, h] = rr
            # batch_loss = GRPO_step(batch, episodes)
            # accelerator.backward(batch_loss)
            # # 执行优化器的步进
            # optimizer.step()
            # # 梯度清零
            # optimizer.zero_grad()
            # name = 'twenty_feedersGLLM.mat'
            # sio.savemat(name, {'REWARD_epochGLLM': reward_multi})





    # if mode == 'test':
    #     true_agent.load()
    #     episodes = 23
    #     begin = 0
    #     root_fixv = 1.01
    #     feeders_list = [1, 14, 23, 43, 61, 76, 84, 102, 106, 127, 153, 168, 195, 197, 224, 235, 246, 252, 263, 269]
    #     min_val = 0.75
    #     max_val = 1.05
    #     rr = 0
    #     reward_test = np.zeros((1, episodes))
    #     voltage11 = np.zeros((1, 275))
    #     current_edges = copy.deepcopy(origin_list)
    #     action_edges = copy.deepcopy(current_edges)
    #
    #     grid_state=reset(begin, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
    #     aj1_tensor = torch.zeros((1, 275 - 20))
    #     aj2_tensor = torch.zeros((1, 275 - 20))
    #     for j in range(275 - 20):  # 原始状态的邻阶矩阵
    #         aj1_tensor[0, j] = origin_list[j][0] - 1  # 邻接矩阵需要从0开始
    #         aj2_tensor[0, j] = origin_list[j][1] - 1
    #     result_tensor_vertical = torch.cat((aj1_tensor, aj2_tensor), dim=0)
    #     result_tensor_vertical_convert = torch.cat((aj2_tensor, aj1_tensor), dim=0)
    #     result_tensor_vertical_expand = torch.cat((result_tensor_vertical, result_tensor_vertical_convert), dim=1)
    #     result_tensor_horizental = torch.cat((aj1_tensor, aj2_tensor), dim=1)  # 存入经验回放[shou,mo]
    #     result_tensor_horizental_convert = torch.cat((aj2_tensor, aj1_tensor), dim=1)  # 存入经验回放[mo,shou]
    #     result_tensor_horizental_expand = torch.cat((result_tensor_horizental, result_tensor_horizental_convert),dim=1)
    #     result_tensor_horizental_expand = result_tensor_horizental_expand.long().to(device)
    #     result_tensor_horizental_expand = result_tensor_horizental_expand.squeeze()  # (128,)存入经验回放池
    #     linjie_matrix = result_tensor_vertical_expand.long().to(device)  # 无向图临接矩阵
    #
    #
    #     for tt in range(episodes):
    #         grid_state = grid_state.to(device)
    #         true_agent.actor = true_agent.actor.to(device)  # 将 actor 移到指定设备
    #
    #         switch_mask = SPM.switch_pairs_Mask_main(current_edges, switch_pairs, flexible_list, feeders_list)
    #         switch_mask = torch.tensor(switch_mask, dtype=torch.float32).to(device)
    #
    #         action_value = true_agent.actor.forward(grid_state,linjie_matrix)  # 将 vv 输入到 actor，并确保在相同设备
    #         masked_probs = true_agent.apply_mask(action_value, switch_mask)
    #         action_switch = torch.argmax(masked_probs)
    #
    #         if (action_switch == 0):
    #             current_edges = action_edges
    #             grid_state_, r = step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, current_edges,root_fixv)
    #
    #         elif ((flexible_list[switch_pairs[action_switch][0] - 1] in current_edges) and (
    #                 flexible_list[switch_pairs[action_switch][1] - 1] not in current_edges)):
    #             action_edges.remove(flexible_list[switch_pairs[action_switch][0] - 1])
    #             action_edges.append(flexible_list[switch_pairs[action_switch][1] - 1])
    #             grid_state_, r = step(begin + tt, bus_data, edge_data, control_edge, pv_data, curve, current_edges,root_fixv)
    #             current_edges = action_edges
    #             r = r - 0.5  # 动作成本
    #
    #         else:
    #             grid_state_, r = np.zeros((1, 1100)), -100  # 直接选择了不满足安全约束的动作
    #
    #         aj1_tensor = torch.zeros((1, 275 - 20))
    #         aj2_tensor = torch.zeros((1, 275 - 20))
    #
    #         for j in range(275 - 20):  # 选出动作后的邻阶矩阵
    #             aj1_tensor[0, j] = action_edges[j][0] - 1  # 邻接矩阵需要从0开始
    #             aj2_tensor[0, j] = action_edges[j][1] - 1
    #         state_tensor_update = torch.cat((aj1_tensor, aj2_tensor), dim=0)
    #         state_tensor_update_convert = torch.cat((aj2_tensor, aj1_tensor), dim=0)
    #         result_tensor_update_expand = torch.cat((state_tensor_update, state_tensor_update_convert), dim=1)
    #
    #         state_tensor_update_horizental = torch.cat((aj1_tensor, aj2_tensor), dim=1)  # [首,末]
    #         state_tensor_update_horizental_convert = torch.cat((aj2_tensor, aj1_tensor), dim=1)  # [末,首]
    #         state_tensor_update_expand = torch.cat(
    #             (state_tensor_update_horizental, state_tensor_update_horizental_convert), dim=1)
    #
    #         state_tensor_update_expand = state_tensor_update_expand.long().to(device)
    #         state_tensor_update_expand = state_tensor_update_expand.squeeze()
    #         linjie_matrix = result_tensor_update_expand.long().to(device)  # 更新临接矩阵
    #
    #         print(tt,flexible_list[switch_pairs[action_switch.cpu().item()][0] - 1],flexible_list[switch_pairs[action_switch.cpu().item()][1] - 1], r)
    #         voltage11 = np.vstack((voltage11, grid_state_[0, :275] * (max_val - min_val) + min_val))
    #
    #         grid_state = grid_state.squeeze()
    #         grid_state_ = grid_state_.squeeze()
    #
    #         rr = rr + r
    #         grid_state=reset(begin+tt+1, bus_data, edge_data, control_edge, pv_data, curve, current_edges, root_fixv)
    #         reward_test[0, tt] = rr
    #
    #
    #     name = 'gsac_test.mat'
    #     # print(type(reward_test), type(voltage11))
    #     savemat = sio.savemat(name, {'REWARD_epoch_plus_testC': reward_test, 'VOLTAGE_TEST': voltage11})
    #     print(rr)




