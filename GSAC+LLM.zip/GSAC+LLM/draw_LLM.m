clc;clear;

% figure(1)    % voltage 无控制
% load('original_test.mat');
% vol=VOLTAGE_TEST(2:24,:);
% x=1:1:275;
% y=0:1:22;
% [xx,yy]=meshgrid(x,y);
% zz=(vol);
% surf(xx,yy,zz);
% xlim([0 300]);
% xticks(0:50:300);
% ylim([0 24]);
% yticks(0:6:24);
% xlabel('节点','FontName','TimesSimSun');
% ylabel('时间/h','FontName','TimesSimSun');
% zlabel('节点电压/p.u.','FontName','TimesSimSun');
% vmin=(min(min(vol)));
% vmax=(max(max(vol)));
% fprintf('vmax=%.3f\n', vmax);fprintf('vmin=%.3f\n', vmin);
% caxis([0.92,1.02]);
% cb=colorbar;
% cb.Ticks = 0.92:0.02:1.02;
% 
% 
% figure(2)  % voltage  vroot=1.02 train
% load('gsac_LLM_test.mat');
% vol=VOLTAGE_GSACLLM_TEST(2:24,:);
% x=1:1:275;
% y=0:1:22;
% [xx,yy]=meshgrid(x,y);
% zz=(vol);
% surf(xx,yy,zz);
% xlim([0 300]);
% xticks(0:50:300);
% ylim([0 24]);
% yticks(0:6:24);
% xlabel('节点','FontName','TimesSimSun');
% ylabel('时间/h','FontName','TimesSimSun');
% zlabel('节点电压/p.u.','FontName','TimesSimSun');
% vmin=(min(min(vol)));
% vmax=(max(max(vol)));
% fprintf('vmax=%.3f\n', vmax);fprintf('vmin=%.3f\n', vmin);
% caxis([0.92,1.02]);
% cb=colorbar;
% cb.Ticks = 0.92:0.02:1.02;
% 
% figure(3)  % 
% load('GSAC_test.mat');
% vol=VOLTAGE_TEST(2:24,:);
% x=1:1:275;
% y=0:1:22;
% [xx,yy]=meshgrid(x,y);
% zz=(vol);
% surf(xx,yy,zz);
% xlim([0 300]);
% xticks(0:50:300);
% ylim([0 24]);
% yticks(0:6:24);
% xlabel('节点','FontName','TimesSimSun');
% ylabel('时间/h','FontName','TimesSimSun');
% zlabel('节点电压/pu','FontName','TimesSimSun');
% vmin=(min(min(vol)));
% vmax=(max(max(vol)));
% fprintf('vmax=%.3f\n', vmax);fprintf('vmin=%.3f\n', vmin);
% caxis([0.94,1.02]);
% cb=colorbar;
% cb.Ticks = 0.94:0.02:1.02;
% 
% 
% figure(4)  % 
% load('gsac_test.mat')
% vol=VOLTAGE_TEST(2:24,:);
% x=1:1:275;
% y=0:1:22;
% [xx,yy]=meshgrid(x,y);
% zz=(vol);
% surf(xx,yy,zz);
% xlim([0 300]);
% xticks(0:50:300);
% ylim([0 24]);
% yticks(0:6:24);
% xlabel('节点','FontName','TimesSimSun');
% ylabel('时间/h','FontName','TimesSimSun');
% zlabel('节点电压/pu','FontName','TimesSimSun');
% vmin=(min(min(vol)));
% vmax=(max(max(vol)));
% fprintf('vmax=%.3f\n', vmax);fprintf('vmin=%.3f\n', vmin);
% caxis([0.94,1.02]);
% cb=colorbar;
% cb.Ticks = 0.94:0.01:1.02;
% 
% figure(5)  % 
% load("twenty_feedersG2_313.mat");
% len2=length(REWARD_epochG2_313);
% len2=250;
% x3=1:1:len2;
% plot(x3,REWARD_epochG2_313(1:1:len2));
% xlabel('回合','FontName','TimesSimSun');
% ylabel('奖励值','FontName','TimesSimSun');
% h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
% set(h1,'Box','off');
% 
% 
% 
% figure(6)  % 
% load("twenty_feedersGLLM.mat");
% len2=length(REWARD_epochGLLM);
% len2=400;
% x3=1:1:len2;
% plot(x3,REWARD_epochGLLM(1:1:len2));
% xlabel('回合','FontName','TimesSimSun');
% ylabel('奖励值','FontName','TimesSimSun');
% h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
% set(h1,'Box','off');

% figure(7)  % 
% load("twenty_feedersG_xg.mat");
% len2=length(REWARD_epochG_xg);
% len2=600;
% x3=1:1:len2;
% plot(x3,REWARD_epochG_xg(1:1:len2));
% xlabel('回合','FontName','TimesSimSun');
% ylabel('奖励值','FontName','TimesSimSun');
% h1=legend('奖励值','FontName','TimesSimSun','FontSize',12);
% set(h1,'Box','off');

figure(8)  % 
load('SAC_test.mat')
vol=VOLTAGE_TEST(2:24,:);
x=1:1:275;
y=0:1:22;
[xx,yy]=meshgrid(x,y);
zz=(vol);
surf(xx,yy,zz);
xlim([0 300]);
xticks(0:50:300);
ylim([0 24]);
yticks(0:6:24);
xlabel('节点','FontName','TimesSimSun');
ylabel('时间/h','FontName','TimesSimSun');
zlabel('节点电压/pu','FontName','TimesSimSun');
vmin=(min(min(vol)));
vmax=(max(max(vol)));
fprintf('vmax=%.3f\n', vmax);fprintf('vmin=%.5f\n', vmin);
caxis([0.94,1.02]);
cb=colorbar;
cb.Ticks = 0.94:0.01:1.02;






