# # import turtle as t
# # import math
# # import random
# # import time
# #
# # # 初始化超级画布
# # t.setup(1000, 800)
# # t.title("坤坤宇宙终极版")
# # t.bgcolor("#FFF0F5")  # 死亡芭比粉背景
# # t.tracer(0)
# # t.colormode(255)
# #
# # # 创建多个画笔（性能优化版）
# # dancers = [t.Turtle() for _ in range(3)]  # 0:头 1:身体 2:篮球
# # lyric = t.Turtle()
# # lyric.hideturtle()
# #
# # # 舞蹈动作参数
# # dance_amplitude = 30  # 扭腰幅度
# # bounce_height = 80    # 篮球弹跳高度
# #
# # def draw_kun_head(angle):
# #     dancers[0].clear()
# #     dancers[0].penup()
# #     dancers[0].goto(math.sin(angle)*10, 100 + math.cos(angle)*5)
# #     dancers[0].pendown()
# #     dancers[0].color("#FFD700")  # 土豪金头部
# #     dancers[0].begin_fill()
# #     dancers[0].circle(35)
# #     dancers[0].end_fill()
# #     # 画中分发型
# #     dancers[0].penup()
# #     dancers[0].goto(-20, 135)
# #     dancers[0].pendown()
# #     dancers[0].color("black")
# #     dancers[0].pensize(3)
# #     dancers[0].setheading(-60)
# #     dancers[0].forward(40)
# #
# # def draw_kun_body(angle):
# #     dancers[1].clear()
# #     dancers[1].penup()
# #     dancers[1].goto(-50 + math.sin(angle)*dance_amplitude, -50)
# #     dancers[1].pendown()
# #     # 渐变背带裤
# #     for y in range(-50, -200, -5):
# #         r = max(0, 100 + y)
# #         g = max(0, 150 + y)
# #         b = 255
# #         dancers[1].color(r, g, b)
# #         dancers[1].pensize(5)
# #         dancers[1].goto(dancers[1].xcor(), y)
# #     # 背带
# #     dancers[1].penup()
# #     dancers[1].goto(-50, -100)
# #     dancers[1].pendown()
# #     dancers[1].goto(-80, 30)
# #     dancers[1].goto(80, 30)
# #     dancers[1].goto(50, -100)
# #
# # def draw_ball(frame):
# #     # 3D抛物线轨迹
# #     x = 150 * math.sin(frame*0.08)
# #     y = bounce_height * abs(math.sin(frame*0.2)) - 100
# #     # 残影效果
# #     for i in range(3, 0, -1):
# #         dancers[2].clear()
# #         dancers[2].penup()
# #         dancers[2].goto(x - i*5, y - i*2)
# #         dancers[2].pendown()
# #         dancers[2].color(255, 165 + i*20, 0)  # 渐隐橙色
# #         dancers[2].begin_fill()
# #         dancers[2].circle(25 - i*2)
# #         dancers[2].end_fill()
# #     # 篮球花纹
# #     dancers[2].penup()
# #     dancers[2].goto(x, y)
# #     dancers[2].pendown()
# #     dancers[2].color("black")
# #     for _ in range(4):
# #         dancers[2].forward(20)
# #         dancers[2].backward(20)
# #         dancers[2].right(90)
# #
# # def draw_lyrics(frame):
# #     lyric.clear()
# #     lyric.penup()
# #     lyric.goto(-300, -250)
# #     lyric.color("#FF1493")
# #     lyrics = [
# #         "鸡你太美~",
# #         "Baby~",
# #         "咯咯哒！",
# #         "全民制作人们~",
# #         "三年练习生~"
# #     ]
# #     # 随机鸡叫彩蛋
# #     if frame % 47 == 0:
# #         lyric.write("🐔：" + random.choice(["咕咕day！", "J你太美！", "练习时长两秒半"]),
# #                    font=("Arial", 20, "bold"))
# #     else:
# #         lyric.write(lyrics[frame % len(lyrics)],
# #                   font=("Arial", 28, "bold"))
# #
# # # 模拟音乐进度条
# # def draw_music_bar(frame):
# #     t.penup()
# #     t.goto(-400, -300)
# #     t.pendown()
# #     t.color("#00FF7F")
# #     t.pensize(10)
# #     t.forward(frame % 800 * 0.02)
# #
# # # 主循环
# # frame = 0
# # try:
# #     while True:
# #         angle = frame * 0.1
# #         draw_kun_head(angle)
# #         draw_kun_body(angle)
# #         draw_ball(frame)
# #         draw_lyrics(frame)
# #         draw_music_bar(frame)
# #         t.update()
# #         time.sleep(0.016)  # 约60帧
# #         frame += 1
# # except:
# #     print("表演结束，感谢收看！")
#
#
# import numpy as np
# import matplotlib.pyplot as plt
#
#
# # 电力系统参数设定
# class PowerSystem:
#     def __init__(self):
#         # 发电机参数 (假设系统有5台发电机)
#         self.num_units = 5
#         self.H_min = np.array([2.5, 3.0, 4.0, 2.0, 3.5])  # 各发电机最小惯量常数(s)
#         self.H_max = np.array([6.0, 8.0, 10.0, 5.0, 7.0])  # 各发电机最大惯量常数(s)
#
#         # 负荷参数
#         self.P_load = 1000  # 系统总负荷(MW)
#         self.P_loss = 50  # 系统损耗(MW)
#
#         # 频率约束
#         self.freq_nominal = 50  # Hz
#         self.rocof_max = 0.5  # 最大频率变化率(Hz/s)
#
#     def calculate_system_inertia(self, H):
#         """计算系统等效惯量"""
#         S_rated = np.array([200, 300, 400, 150, 350])  # 各发电机额定容量(MVA)
#         H_sys = np.sum(H * S_rated) / np.sum(S_rated)
#         return H_sys
#
#     def evaluate_frequency_response(self, H):
#         """评估频率响应"""
#         S_rated = np.array([200, 300, 400, 150, 350])
#         total_inertia = np.sum(H * S_rated)
#
#         # 假设最大发电损失为最大单机容量
#         max_loss = np.max(S_rated)
#
#         # 计算初始ROCOF (Rate of Change of Frequency)
#         rocof = max_loss / (2 * total_inertia) * self.freq_nominal
#
#         # 计算频率最低点
#         delta_f = (max_loss ** 2) / (4 * total_inertia * np.sum(S_rated))
#
#         return rocof, delta_f
#
#
# # 粒子群优化算法
# class PSO:
#     def __init__(self, power_system, num_particles=30, max_iter=100):
#         self.ps = power_system
#         self.num_particles = num_particles
#         self.max_iter = max_iter
#         self.w = 0.729  # 惯性权重
#         self.c1 = 1.49445  # 认知系数
#         self.c2 = 1.49445  # 社会系数
#
#         # 初始化粒子位置和速度
#         self.positions = np.zeros((num_particles, self.ps.num_units))
#         self.velocities = np.zeros((num_particles, self.ps.num_units))
#
#         for i in range(num_particles):
#             self.positions[i] = np.random.uniform(self.ps.H_min, self.ps.H_max)
#             self.velocities[i] = np.random.uniform(-1, 1, size=self.ps.num_units)
#
#         # 初始化个体和全局最优
#         self.pbest_positions = self.positions.copy()
#         self.pbest_values = np.full(num_particles, np.inf)
#         self.gbest_position = None
#         self.gbest_value = np.inf
#
#         # 记录收敛过程
#         self.convergence = []
#
#     def objective_function(self, H):
#         """目标函数：最小化系统惯量，同时满足频率约束"""
#         rocof, delta_f = self.ps.evaluate_frequency_response(H)
#
#         # 惩罚因子
#         penalty = 0
#         if rocof > self.ps.rocof_max:
#             penalty += 1000 * (rocof - self.ps.rocof_max) ** 2
#
#         # 确保各发电机惯量在允许范围内
#         for i in range(self.ps.num_units):
#             if H[i] < self.ps.H_min[i]:
#                 penalty += 1000 * (self.ps.H_min[i] - H[i]) ** 2
#             if H[i] > self.ps.H_max[i]:
#                 penalty += 1000 * (H[i] - self.ps.H_max[i]) ** 2
#
#         # 目标值为系统等效惯量加上惩罚项
#         H_sys = self.ps.calculate_system_inertia(H)
#         return H_sys + penalty
#
#     def optimize(self):
#         for iter in range(self.max_iter):
#             for i in range(self.num_particles):
#                 # 评估当前粒子
#                 current_value = self.objective_function(self.positions[i])
#
#                 # 更新个体最优
#                 if current_value < self.pbest_values[i]:
#                     self.pbest_values[i] = current_value
#                     self.pbest_positions[i] = self.positions[i].copy()
#
#                 # 更新全局最优
#                 if current_value < self.gbest_value:
#                     self.gbest_value = current_value
#                     self.gbest_position = self.positions[i].copy()
#
#             # 更新粒子速度和位置
#             for i in range(self.num_particles):
#                 r1, r2 = np.random.random(), np.random.random()
#                 cognitive = self.c1 * r1 * (self.pbest_positions[i] - self.positions[i])
#                 social = self.c2 * r2 * (self.gbest_position - self.positions[i])
#                 self.velocities[i] = self.w * self.velocities[i] + cognitive + social
#                 self.positions[i] += self.velocities[i]
#
#             # 记录当前最优值
#             self.convergence.append(self.gbest_value)
#
#             # 打印进度
#             if (iter + 1) % 10 == 0:
#                 print(f"Iteration {iter + 1}/{self.max_iter}, Best H_sys: {self.gbest_value:.4f}")
#
#         return self.gbest_position, self.gbest_value
#
#     def plot_convergence(self):
#         plt.figure(figsize=(10, 6))
#         plt.plot(self.convergence, linewidth=2)
#         plt.title('PSO Convergence')
#         plt.xlabel('Iteration')
#         plt.ylabel('System Inertia (s)')
#         plt.grid(True)
#         plt.show()
#
#
# # 运行优化
# if __name__ == "__main__":
#     ps = PowerSystem()
#     pso = PSO(ps, num_particles=50, max_iter=200)
#
#     best_H, best_value = pso.optimize()
#
#     print("\nOptimization Results:")
#     print(f"Best System Inertia: {ps.calculate_system_inertia(best_H):.4f} s")
#     print("Generator H values:")
#     for i, h in enumerate(best_H):
#         print(f"Generator {i + 1}: {h:.4f} s (Range: {ps.H_min[i]} - {ps.H_max[i]} s)")
#
#     rocof, delta_f = ps.evaluate_frequency_response(best_H)
#     print(f"\nFrequency Response Analysis:")
#     print(f"ROCOF: {rocof:.4f} Hz/s (Max allowed: {ps.rocof_max} Hz/s)")
#     print(f"Frequency Nadir: {ps.freq_nominal - delta_f:.4f} Hz")
#
#     pso.plot_convergence()

import numpy as np
import matplotlib.pyplot as plt

# 模拟训练步数（假设100步）
steps = np.arange(100)

# 模拟J_GRPO动态：初期波动，后期收敛
J_GRPO = np.zeros(100)
for i in range(100):
    # 策略比率随训练逐渐优化（假设初期随机，后期稳定）
    if i < 30:
        ratio = np.random.uniform(0.8, 1.2, 10)  # 初期波动
    else:
        ratio = np.clip(1.0 + 0.1 * np.sin(i / 10), 0.8, 1.2)  # 后期小幅调整

    # 计算裁剪后的策略项
    clipped_ratio = np.clip(ratio, 0.8, 1.2)
    advantage = (np.array([1.2, 1.5, 1.8, 1.3, 1.6, 1.1, 1.9, 1.4, 1.7, 2.0]) - 1.55) / 0.29
    policy_term = np.mean(np.minimum(ratio * advantage, clipped_ratio * advantage))

    # KL散度项（假设随训练减小）
    kl = np.maximum(0, 0.1 * np.exp(-i / 50))
    J_GRPO[i] = policy_term - 0.1 * kl

# 绘制曲线
plt.figure(figsize=(10, 5))
plt.plot(steps, J_GRPO, label='J_GRPO', color='blue', linewidth=2)
plt.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
plt.xlabel('Training Steps', fontsize=12)
plt.ylabel('J_GRPO Value', fontsize=12)
plt.title('Simulated GRPO Objective Function (10 Rewards in [1, 2])', fontsize=14)
plt.legend()
plt.grid(True, alpha=0.3)
plt.show()
